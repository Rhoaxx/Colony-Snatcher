#!/usr/bin/env python3
"""
PIXL Rearray Processor  (v2: image-based detection)
===================================================
Drop-in replacement for the previous pixl_rearray_processor.py / OmnitrayRearray.exe (now renamed colony_picker_8_sector_momentum).

Instead of reading the PIXL's own colony picks (rearray template .tsv + Project.xml), this version looks at
Original.png, detects colonies itself inside the 8 "Shimadzu 8 Well" sectors on the SBS rectangular plate, and picks
ONE colony per sector. A sector without a clean colony is topped up with lower-confidence colonies (flagged in the
log); a sector with nothing acceptable stays empty and is reported exactly like a missing sector before.

Usage (called by Momentum with a single comma-delimited quoted argument string, as before):
    colony_picker_8_sector_momentum.exe "<pixl_output_folder>,<source_plate_name>,<target_plate_name>,<start_well>"

    pixl_output_folder  : folder containing Original.png (Project.xml / SourcePlateColonySummary.csv next to it, if present,
                          supply the agar depth used for the image calibration)
    source_plate_name   : e.g. OmniSource1
    target_plate_name   : e.g. TargetPlate1
    start_well          : first well on the 96-well DWP target (e.g. A1, A9); sector N goes to well start+N

Output (same as before):
    <folder>\\<SourceName>_FinalRearray.csv     rearray file (sector N -> well start+N; missing sectors skipped)
    <folder>\\<SourceName>_rearray-logs.txt     only when sectors are missing: "<Source>,Sector<N>,<Well>[,...]"
    C:\\colony_picker\\OmnitrayRearray\\Logs\\<SourceName>_Location.csv
    C:\\colony_picker\\OmnitrayRearray\\Logs\\OmnitrayRearrayLog.txt   (appended run log; now also lists LOW-confidence picks)
    additionally: <folder>\\<SourceName>_picks.png  annotated image with the sector rectangles and picks.

Requires: numpy, scipy, opencv-python   (pip install numpy scipy opencv-python)
"""

import sys
import os
import csv
import math
import datetime
import json
import math
import re
import xml.etree.ElementTree as ET

import numpy as np
import cv2
from scipy import ndimage as ndi
from scipy.spatial import cKDTree

# Order of the two coordinates in the CSV rows. The previous processor wrote  X, Y  (see write_rearray_csv in
# the old script). Set to 'YX' if the PIXL rearray step expects Y first (as the PIXL .tsv template does).
COORD_ORDER = os.environ.get('RP_COORD_ORDER', 'XY')
LOGS_DIR = os.environ.get('RP_LOGS_DIR', r"C:\colony_picker\OmnitrayRearray\Logs")
DRIVE_REMAP = os.environ.get('RP_NO_DRIVE_REMAP') is None       # C: -> X: for the locally mapped PIXL drive

# ----------------------------------------------------------------------------- calibration & geometry
REF_W = 1728
CX, CY = 849.5, 865.5
DEFAULT_SCALE = {'petri': 10.83, 'sbs': 10.85, 'sbs8': 10.97}


def scale_for_agar(a):
    return 0.0229 * a + 10.7612


# Singer 'Shimadzu 8 Well' sector split: fractions of the 109 x 73 mm pickable area (the red dotted boxes in the PIXL image)
SHIM8_FX = [(0, .16), (.28, .44), (.54, .70), (.83, .99)]
SHIM8_FY = [(.03, .43), (.60, 1.0)]
SECTOR_COLS = [(-54.5 + 109 * a, -54.5 + 109 * b) for a, b in SHIM8_FX]
SECTOR_ROWS = [(-36.5 + 73 * a, -36.5 + 73 * b) for a, b in SHIM8_FY]
PETRI_R, PETRI_CY, SBS_X, SBS_Y = 39.5, 0.3, 54.5, 36.5


def sector_boxes():
    return {r * 4 + c: (SECTOR_COLS[c][0], SECTOR_ROWS[r][0], SECTOR_COLS[c][1], SECTOR_ROWS[r][1])
            for r in range(2) for c in range(4)}


def region_info(x, y, kind):
    """(inside, sector, edge_mm) for mm coordinates (arrays). sector = 0 on unsectored plates, -1 outside."""
    x = np.asarray(x, float); y = np.asarray(y, float)
    sec = -np.ones(x.shape, np.int16)
    if kind == 'petri':
        edge = PETRI_R - np.hypot(x, y - PETRI_CY); ins = edge >= 0; sec[ins] = 0
    elif kind == 'sbs':
        edge = np.minimum(SBS_X - np.abs(x), SBS_Y - np.abs(y)); ins = edge >= 0; sec[ins] = 0
    else:
        edge = np.full(x.shape, -1.0)
        for s, (x0, y0, x1, y1) in sector_boxes().items():
            e = np.minimum(np.minimum(x - x0, x1 - x), np.minimum(y - y0, y1 - y)); ins = e >= 0
            sec[ins] = s; edge = np.where(ins, e, edge)
    return sec >= 0, sec, edge


# ----------------------------------------------------------------------------- detection
SIGMAS = [1.6 * 2 ** (i / 2.0) for i in range(8)]
K_NOISE, K_BIG, BIG_FROM, STRIDE = 4.0, 2.0, 3, 3
GLINT_RATIO, GLINT_CENTER_RATIO = 2.6, 1.35


def gblur(img, sigma):
    """Gaussian blur with the exact kernel used by the JS engine (ksize = round(6*sigma+1)|1, reflect-101 borders)."""
    ks = int(round(sigma * 6 + 1)) | 1
    ks = max(ks, 3)
    r = (ks - 1) // 2
    k = np.exp(-((np.arange(ks) - r) ** 2) / (2.0 * sigma * sigma)).astype(np.float32)
    k /= k.sum()
    return cv2.sepFilter2D(img, cv2.CV_32F, k, k, borderType=cv2.BORDER_REFLECT_101)


def luminance(bgr):
    b, g, r = [bgr[..., i].astype(np.float32) for i in range(3)]
    return (0.299 * r + 0.587 * g + 0.114 * b).astype(np.float32)


def log_stack(gray):
    out = []
    for s in SIGMAS:
        if s >= 6.0:
            half = cv2.resize(gray, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
            g = gblur(half, s / 2)
            L = -(s * s) * cv2.Laplacian(g, cv2.CV_32F, ksize=1) / 4.0
            L = cv2.resize(L, (gray.shape[1], gray.shape[0]), interpolation=cv2.INTER_LINEAR)
        else:
            g = gblur(gray, s)
            L = -(s * s) * cv2.Laplacian(g, cv2.CV_32F, ksize=1)
        out.append(L)
    return np.stack(out)


def find_seeds(gray, mask):
    st = log_stack(gray)
    ms = mask[::STRIDE, ::STRIDE]
    vals = st[:, ::STRIDE, ::STRIDE][:, ms]
    med = np.median(vals, axis=1)
    noise = np.array([max(m - np.percentile(v, 15.87), 1e-3) for v, m in zip(vals, med)])
    kk = np.array([K_BIG if k >= BIG_FROM else K_NOISE for k in range(len(SIGMAS))])
    thr = (med + kk * noise)[:, None, None]
    nm = ndi.maximum_filter(st, size=(3, 3, 3), mode='nearest')
    peak = (st == nm) & (st > thr) & mask[None]
    ks, ys, xs = np.nonzero(peak)
    if len(ks) == 0:
        return np.zeros((0, 4))
    sg = np.array(SIGMAS)[ks]
    arr = np.c_[xs, ys, sg * 1.4142, st[ks, ys, xs] / noise[ks]]
    arr = arr[np.lexsort((-arr[:, 3], -arr[:, 2]))]
    n = len(arr); alive = np.ones(n, bool)
    tree = cKDTree(arr[:, :2])
    for i in range(n):
        if not alive[i]: continue
        rr = arr[i, 2]
        for j in tree.query_ball_point(arr[i, :2], r=rr * 1.1):
            if j <= i or not alive[j]: continue
            if arr[j, 2] < arr[i, 2] * 0.999: alive[j] = False
            elif np.hypot(*(arr[i, :2] - arr[j, :2])) < 0.7 * rr: alive[j] = False
    return arr[alive]


def hull_area(px, py, shape, tol=0.5):
    """Pixels inside the convex hull of the mask pixels (monotone chain; hull edge tolerance 0.5 px, as in the JS engine)."""
    pts = sorted(zip(px.tolist(), py.tolist()))
    def cross(o, a, b): return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lower, upper = [], []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0: lower.pop()
        lower.append(p)
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0: upper.pop()
        upper.append(p)
    hull = lower[:-1] + upper[:-1]
    if len(hull) < 3: return len(pts)
    Y, X = np.mgrid[0:shape[0], 0:shape[1]]
    ok = np.ones(shape, bool)
    for q in range(len(hull)):
        a, b = hull[q], hull[(q + 1) % len(hull)]
        el = math.hypot(b[0] - a[0], b[1] - a[1]) or 1.0
        ok &= ((b[0] - a[0]) * (Y - a[1]) - (b[1] - a[1]) * (X - a[0])) / el >= -tol
    return int(ok.sum())


def analyze(img_bgr, kind, agar=None, scale=None):
    """Detect candidate colonies. Returns (list of dict, scale_px_per_mm_in_this_image)."""
    H0, W0 = img_bgr.shape[:2]
    f = W0 / REF_W
    S = scale if scale else (scale_for_agar(agar) if agar is not None and np.isfinite(agar) else DEFAULT_SCALE[kind])
    S *= f
    cx0_, cy0_ = CX * f, CY * f
    yy, xx = np.mgrid[0:H0, 0:W0]
    ins, _, _ = region_info((xx - cx0_) / S, (yy - cy0_) / S, kind)
    if not ins.any():
        return [], S
    ys_, xs_ = np.nonzero(ins)
    M = 64
    cx0 = max(0, xs_.min() - M); cy0 = max(0, ys_.min() - M)
    cx1 = min(W0, xs_.max() + M + 1); cy1 = min(H0, ys_.max() + M + 1)
    cw = (cx1 - cx0) // 2 * 2; ch = (cy1 - cy0) // 2 * 2
    cx1, cy1 = cx0 + cw, cy0 + ch
    g2 = luminance(img_bgr)[cy0:cy1, cx0:cx1].copy()
    m2 = ins[cy0:cy1, cx0:cx1]
    gs = gblur(g2, 1.0)
    hp = gs - gblur(gs, 6.0)
    hv = hp[::STRIDE, ::STRIDE][m2[::STRIDE, ::STRIDE]]
    noise_px = 1.4826 * np.median(np.abs(hv - np.median(hv))) + 1e-3
    seeds = find_seeds(g2, m2)
    if len(seeds) == 0:
        return [], S
    H, W = gs.shape
    gx = cv2.Sobel(gs, cv2.CV_32F, 1, 0, ksize=3) / 8.0
    gy = cv2.Sobel(gs, cv2.CV_32F, 0, 1, ksize=3) / 8.0
    gm = np.hypot(gx, gy)
    cen = seeds[:, :2]; rr = seeds[:, 2]
    tree = cKDTree(cen)
    K3 = np.ones((3, 3), np.uint8)
    st4 = ndi.generate_binary_structure(2, 1)
    rows = []
    for i, (x, y, r0, _) in enumerate(seeds):
        x = int(x); y = int(y)
        win = int(2.8 * r0) + 4
        x0, x1 = max(0, x - win), min(W, x + win + 1)
        y0, y1 = max(0, y - win), min(H, y + win + 1)
        patch = gs[y0:y1, x0:x1]
        Y, X = np.mgrid[y0:y1, x0:x1]
        d64 = np.hypot(X - x, Y - y)
        wi = (d64 * d64 - r0 * r0).astype(np.float32).astype(np.float64)   # float32 rounding on ties, as in the JS engine
        di = d64.astype(np.float32)
        cell = np.ones(patch.shape, bool)
        for j in tree.query_ball_point([x, y], r=win * 1.6 + 30):
            if j == i: continue
            dj = (X - cen[j, 0]) ** 2 + (Y - cen[j, 1]) ** 2
            cell &= wi <= (dj - rr[j] ** 2)
        far = (di > 1.8 * r0) & (di < 2.8 * r0 + 3)
        fc = far & cell
        bgv = patch[fc] if fc.sum() > 10 else patch[far]
        bg = np.percentile(bgv, 25) if bgv.size else np.percentile(patch, 10)
        core = di <= max(0.5 * r0, 1.2)
        pk = float(np.percentile(patch[core], 75)); dl = pk - bg
        if not np.isfinite(dl) or dl < 2.0 * noise_px: continue
        lvl = bg + 0.5 * dl
        maxD = 2.4 * r0 + 2
        # specular glint guard (see colony_detect.js)
        dl_body, dl_top = dl, dl
        t0 = bg + max(5 * noise_px, 0.2 * dl)
        body = patch[(di <= maxD) & cell & (patch > t0)]
        glint = False; dl2 = dl; dl80 = dl
        if body.size >= 6:
            dl80 = np.percentile(body, 80) - bg; dl2 = np.percentile(body, 50) - bg
            glint = dl2 > 2.0 * noise_px and dl > GLINT_RATIO * dl2
        if dl2 > 2.0 * noise_px and dl2 < dl: dl_body = dl2
        dl_top = max(dl80, 1e-6)
        if glint:
            dl = dl2; pk = bg + dl2; lvl = bg + 0.5 * dl2
        m = (patch > lvl) & (di <= maxD)
        mc = m & cell
        lab, n = ndi.label(mc)
        cy_ = min(max(int(round(y - y0)), 0), lab.shape[0] - 1); cx_ = min(max(int(round(x - x0)), 0), lab.shape[1] - 1)
        l0 = lab[cy_, cx_]
        if l0 == 0:
            if n == 0: continue
            idx = ndi.distance_transform_edt(lab == 0, return_indices=True)[1]
            l0 = lab[idx[0][cy_, cx_], idx[1][cy_, cx_]]
        comp = ndi.binary_fill_holes(lab == l0)
        area = int(comp.sum())
        if area < 6: continue
        cu = comp.astype(np.uint8)
        ysc, xsc = np.nonzero(comp); mx, my = xsc.mean(), ysc.mean()
        cov = np.cov(np.vstack([xsc - mx, ysc - my]))
        ev = np.sort(np.linalg.eigvalsh(cov))[::-1]
        ar = float(np.sqrt(ev[0] / max(ev[1], 1e-6)))
        req = math.sqrt(area / math.pi)
        er4 = ndi.binary_erosion(comp, structure=st4, border_value=0)
        by, bx = np.nonzero(comp & ~er4)
        rad = np.hypot(bx - mx, by - my)
        radial_cv = float(rad.std() / (rad.mean() + 1e-6))
        dil = cv2.dilate(cu, K3) > 0
        ero = cv2.erode(cu, K3, borderType=cv2.BORDER_CONSTANT, borderValue=0) > 0
        ring_pix = dil & ~comp
        touch = float((ring_pix & (m & ~cell)).sum() / max(ring_pix.sum(), 1))
        gband = dil & ~ero
        edge_w = float(dl / (gm[y0:y1, x0:x1][gband].mean() + 1e-3) / max(req, 1.0))
        dist_out = ndi.distance_transform_edt(~comp)
        mwin = m2[y0:y1, x0:x1]
        rg = (dist_out > 0.25 * req + 1) & (dist_out < 0.9 * req + 3) & mwin
        ring_max = float((np.percentile(patch[rg], 95) - bg) / dl) if rg.sum() > 8 else 0.0
        solidity = float(area / max(hull_area(xsc, ysc, comp.shape), area))
        inscr = float(ndi.distance_transform_edt(comp).max() / max(req, 1.0))
        sat = float((g2[y0:y1, x0:x1][comp] >= 240).mean())
        fill = float((patch[di <= 0.5 * max(req, 1.5)].mean() - bg) / dl)
        clutter = float((np.percentile(bgv, 90) - np.percentile(bgv, 10)) / noise_px) if bgv.size > 10 else 0.0
        hal = (dist_out > 1.0) & (dist_out < 2.5 * req + 4) & mwin & cell
        halo = float((gm[y0:y1, x0:x1][hal] > 2 * noise_px).mean()) if hal.sum() > 10 else 0.0
        ccx, ccy = mx, my
        if dl > GLINT_CENTER_RATIO * dl_top:        # centre on the colony body, not on a specular highlight
            cm = (patch > bg + 0.5 * dl_body) & (di <= maxD) & cell
            s0 = None
            if cm[cy_, cx_]: s0 = (cy_, cx_)
            elif cm.any():
                idx = ndi.distance_transform_edt(~cm, return_indices=True)[1]
                s0 = (idx[0][cy_, cx_], idx[1][cy_, cx_])
            if s0 is not None:
                l2, _ = ndi.label(cm)
                reg = l2 == l2[s0]
                n2 = int(reg.sum())
                if 6 <= n2 <= 10 * area + 40:
                    yy2, xx2 = np.nonzero(reg); ccx, ccy = xx2.mean(), yy2.mean()
        gxp, gyp = ccx + x0 + cx0, ccy + y0 + cy0
        xm, ym = (gxp - cx0_) / S, (gyp - cy0_) / S
        ins1, sc1, ed1 = region_info(np.array([xm]), np.array([ym]), kind)
        rows.append(dict(x=float(gxp), y=float(gyp), r_seed=float(r0), r_px=float(req), r_mm=float(req / S),
                         snr=float(dl / noise_px), axis_ratio=ar, radial_cv=radial_cv, edge_w=edge_w, touch=touch,
                         ring_max=ring_max, solidity=solidity, inscr=inscr, sat=sat, fill=fill, clutter=clutter, halo=halo,
                         edge_mm=float(ed1[0]), sector=int(sc1[0]), x_mm=float(xm), y_mm=float(ym)))
    if not rows:
        return rows, S
    c2 = np.array([[r['x'], r['y']] for r in rows]); r2 = np.array([r['r_px'] for r in rows])
    t2 = cKDTree(c2)
    for k, r in enumerate(rows):
        nb = t2.query_ball_point(c2[k], r=r2[k] * 3 + 60)
        gaps = [np.hypot(*(c2[k] - c2[j])) - r2[k] - r2[j] for j in nb if j != k]
        r['gap_mm'] = float((min(gaps) if gaps else 50 * S) / S)
        r['dens3'] = int(sum(1 for j in t2.query_ball_point(c2[k], 3.0 * S) if j != k))
    return rows, S


# ----------------------------------------------------------------------------- scoring & selection
MODELS = json.loads(r'''{"model":{"features":["radial_cv","axis_ratio","edge_w","ring_max","gap_mm","dens3","edge_mm","snr","touch","solidity","inscr","fill","sat","clutter","halo"],"w":[-0.9878775430999591,-1.0134364704227854,-2.8306600593656235,-1.2807593006367421,0.09209367608957374,-0.02188336684771793,0.4537475070978126,1.8848809789266834,-0.7453924518594198,6.378692439709168,2.149773903399389,0.43545259223158345,-20.850216516818033,0.5344269612212657,-3.619654573189738],"b":-10.707421540896483},"real":{"features":["radial_cv","axis_ratio","edge_w","ring_max","touch","solidity","inscr","fill","sat","clutter","halo","lsnr","lr","gapc","dens","edge_mm"],"w":[-7.5541015538556175,-0.59887765516387,-1.6170540408517282,0.3105603354255493,-4.151849787949336,6.04888145500508,6.180937570918918,5.497938870123086,-26.823516894026717,-0.7499364911402016,-2.548623588832721,2.8196449302744075,1.8842610291981574,-0.08845211554608032,0.4330102458278428,0.4109233460283216],"b":-22.80555244659626}}''')
MODEL, REAL_MODEL = MODELS['model'], MODELS['real']
clipR = lambda v, a, b: min(b, max(a, v))


def feature_vector(c):
    return dict(radial_cv=clipR(c['radial_cv'], 0, .6), axis_ratio=clipR(c['axis_ratio'], 1, 3), edge_w=clipR(c['edge_w'], 0, 3),
                ring_max=clipR(c['ring_max'], -.3, 1.5), gap_mm=clipR(c['gap_mm'], -.5, 3), dens3=clipR(c['dens3'], 0, 30),
                edge_mm=clipR(c['edge_mm'], 0, 4.0), snr=math.log1p(clipR(c['snr'], 0, 120)), touch=clipR(c['touch'], 0, 1),
                solidity=clipR(c['solidity'], .5, 1), inscr=clipR(c['inscr'], .4, 1.05), fill=clipR(c['fill'], 0, 1.1),
                sat=clipR(c['sat'], 0, .5), clutter=math.log1p(clipR(c['clutter'], 0, 60)), halo=clipR(c['halo'], 0, .7))


def score(c):
    f = feature_vector(c)
    return MODEL['b'] + sum(w * f[n] for w, n in zip(MODEL['w'], MODEL['features']))


def p_real(c):
    f = dict(radial_cv=clipR(c['radial_cv'], 0, .6), axis_ratio=clipR(c['axis_ratio'], 1, 3), edge_w=clipR(c['edge_w'], 0, 3),
             ring_max=clipR(c['ring_max'], 0, 2), touch=clipR(c['touch'], 0, 1), solidity=clipR(c['solidity'], .5, 1),
             inscr=clipR(c['inscr'], .4, 1.05), fill=clipR(c['fill'], 0, 1.1), sat=clipR(c['sat'], 0, .5),
             clutter=math.log1p(clipR(c['clutter'], 0, 60)), halo=clipR(c['halo'], 0, .7), lsnr=math.log1p(clipR(c['snr'], 0, 300)),
             lr=math.log(clipR(c['r_px'], 1.5, 40)), gapc=clipR(c['gap_mm'], -.5, 2.5), dens=math.log1p(c['dens3']),
             edge_mm=clipR(c['edge_mm'], 0, 6))
    z = REAL_MODEL['b'] + sum(w * f[n] for w, n in zip(REAL_MODEL['w'], REAL_MODEL['features']))
    return 1 / (1 + math.exp(-z)) if z > -700 else 0.0


def is_artifact(c):
    return (c['halo'] > .45 or c['sat'] > .05 or c['fill'] < .75 or c['solidity'] < .80 or (c['clutter'] > 15 and c['ring_max'] > .6)
            or (c['ring_max'] > 1.0 and c['touch'] > .25) or (c['ring_max'] > .8 and c['touch'] > .2 and c['clutter'] > 8))


def tier_of(c):
    if is_artifact(c): return 4
    if (c['touch'] <= .02 and c['radial_cv'] <= .20 and c['axis_ratio'] <= 1.5 and c['snr'] >= 5 and c['edge_mm'] >= 1.0
            and c['gap_mm'] >= .15 and c['inscr'] >= .85 and c['solidity'] >= .93): return 1
    if (c['touch'] <= .15 and c['radial_cv'] <= .30 and c['axis_ratio'] <= 1.9 and c['snr'] >= 4 and c['edge_mm'] >= .8
            and c['inscr'] >= .78): return 2
    if c['radial_cv'] <= .45 and c['snr'] >= 3 and c['edge_mm'] >= .5: return 3
    return 4


def rank(cands, size_floor_frac=0.35, abs_floor=0.10):
    for c in cands:
        c['score'] = score(c); c['tier'] = tier_of(c); c['preal'] = p_real(c)
    g = {}
    for c in cands:
        if c['preal'] >= .5 and c['tier'] <= 2: g.setdefault(c['sector'], []).append(c['r_mm'])
    ref = {k: float(np.median(v)) for k, v in g.items() if len(v) >= 3}
    for c in cands: c['r_real_ref'] = ref.get(c['sector'])
    g1, g2 = {}, {}
    for c in cands:
        if c['tier'] == 1: g1.setdefault(c['sector'], []).append(c['r_mm'])
        if c['tier'] <= 2: g2.setdefault(c['sector'], []).append(c['r_mm'])
    allm = float(np.median([c['r_mm'] for c in cands])) if cands else 0
    for c in cands:
        s = c['sector']
        c['r_ref'] = float(np.median(g1[s])) if s in g1 else (float(np.median(g2[s])) if s in g2 else allm)
        c['too_small'] = c['r_mm'] < max(abs_floor, size_floor_frac * c['r_ref'])
        if c['too_small'] and c['tier'] < 4: c['tier'] = 3
    return cands



MIN_REAL, SATELLITE_W, DENSE_REAL, TIER_PENALTY, FILL_MIN_SNR, GAP_W, ROUND_W = 0.9, 3.0, 0.95, 1.5, 8, 0.5, 1.0
ALIVE_POP, ALIVE_REAL, ALIVE_SCORE, CROWD_N, CROWD_REAL = 4, 0.6, -3.6, 120, 0.5
LAWN_R, TINY_R, TINY_GAP, T1_REAL, T1_GAP, T1_R = 2.0, 0.3, 0.25, 0.8, 0.25, 0.3


def round_pen(c):
    return ROUND_W * (max(0, c['axis_ratio'] - 1.10) * 4 + max(0, c['radial_cv'] - 0.10) * 6)


def _pick_from(pool, k, out, max_tier, min_sep):
    def sat_pen(c):
        if not c['r_real_ref']: return 0.0
        return SATELLITE_W * max(0.0, math.log(c['r_real_ref'] / max(c['r_mm'], .05)) - math.log(1.6))
    def adj(c):
        return (c['score'] - sat_pen(c) - TIER_PENALTY * (c['tier'] - 1) - round_pen(c) + GAP_W * min(2.5, max(-.5, c['gap_mm'])))
    taken = {id(o) for o in out}
    for c in sorted([c for c in pool if c['tier'] <= max_tier and id(c) not in taken], key=adj, reverse=True):
        if len(out) >= k: break
        if all(math.hypot(c['x_mm'] - o['x_mm'], c['y_mm'] - o['y_mm']) >= min_sep for o in out): out.append(c)
    return out


def select(cands, n, per_sector=None, sectors=None, fill_low=False, min_sep=1.0, min_real=MIN_REAL,
           min_score=-1.0, fill_min=-2.0, dense_fallback=True):
    """per_sector: int or list (colonies per sector) -> sector mode; otherwise the n best over the plate."""
    rank(cands)
    for c in cands: c['lowConf'] = False

    def strict_ok(c):
        return c['preal'] >= min_real and (c['score'] >= min_score or (c['tier'] == 1 and c['score'] >= fill_min))

    def fill_ok(c):
        return (c['preal'] >= .7 and c['score'] >= fill_min and c['snr'] >= FILL_MIN_SNR and c['axis_ratio'] <= 1.6 and c['solidity'] >= .85)

    if per_sector is not None:
        secs = sectors if sectors is not None else list(range(8))
        chosen = []
        for s in secs:
            k = per_sector[s] if isinstance(per_sector, (list, tuple)) else per_sector
            if k <= 0: continue
            pool = [c for c in cands if c['sector'] == s]
            # sector-level evidence: a growing sector holds a population of confident colonies / many candidates
            pop = sum(1 for c in pool if c['preal'] >= .5 and c['tier'] <= 2)
            alive, crowded = pop >= ALIVE_POP, len(pool) >= CROWD_N
            if pop < ALIVE_POP:      # lone tiny specks touching a neighbour (dust, droplets, glints) are not colonies
                pool = [c for c in pool if not (c['r_mm'] < TINY_R and c['gap_mm'] < TINY_GAP)]
            out = _pick_from([c for c in pool if strict_ok(c)], k, [], 2, min_sep)
            if len(out) < k:         # clearly isolated, round, tier-1 colony with slightly lower confidence
                _pick_from([c for c in pool if c['tier'] == 1 and c['preal'] >= T1_REAL and c['score'] >= fill_min
                            and c['gap_mm'] >= T1_GAP and c['r_mm'] >= T1_R], k, out, 1, min_sep)
            if not out and (alive or crowded):   # populated sector, no clean colony: relax confidence gate, flag LOW
                pr = ALIVE_REAL if alive else CROWD_REAL
                _pick_from([c for c in pool if c['preal'] >= pr and c['score'] >= ALIVE_SCORE and c['snr'] >= 5], k, out, 3, min_sep)
                for c in out: c['lowConf'] = True
            if len(out) < k and fill_low:
                b = len(out)
                _pick_from([c for c in pool if fill_ok(c)], k, out, 3, min_sep)
                for c in out[b:]: c['lowConf'] = True
            if len(out) < k and dense_fallback:   # crowded / confluent sector: best-separated confident colonies, LOW
                b = len(out)
                _pick_from([c for c in pool if c['preal'] >= DENSE_REAL and c['sat'] <= .05 and c['fill'] >= .75 and c['solidity'] >= .8
                            and c['edge_mm'] >= 1.0 and c['halo'] <= .2 and not (c['ring_max'] > 1.0 and c['touch'] > .25)], k, out, 4, min_sep)
                for c in out[b:]: c['lowConf'] = True
            if not out and dense_fallback:        # worst case (confluent lawn): best isolated large lobe, LOW
                _pick_from([c for c in pool if c['r_mm'] >= LAWN_R and c['snr'] >= 6 and c['solidity'] >= .8 and c['fill'] >= .75
                            and c['halo'] <= .2 and c['sat'] <= .05 and c['edge_mm'] >= 1.5 and c['axis_ratio'] <= 1.9
                            and c['touch'] <= .1 and c['gap_mm'] >= .4 and c['ring_max'] <= 1.0], k, out, 4, min_sep)
                for c in out: c['lowConf'] = True
            chosen += out
        return chosen
    pool = [c for c in cands if c['sector'] >= 0]
    out = _pick_from([c for c in pool if strict_ok(c)], n, [], 2, min_sep)
    if len(out) < n and fill_low:
        b = len(out)
        _pick_from([c for c in pool if fill_ok(c)], n, out, 3, min_sep)
        for c in out[b:]: c['lowConf'] = True
    return out


# ---------------------------------------------------------------------------
# Well-layout helpers  (unchanged)
# ---------------------------------------------------------------------------
ROWS = list("ABCDEFGH")
COLS = list(range(1, 13))
TOTAL_WELLS = 96


def well_index(well_str: str) -> int:
    well_str = well_str.strip().upper()
    row_letter = well_str[0]
    col_number = int(well_str[1:])
    if row_letter not in ROWS:
        raise ValueError(f"Invalid row letter '{row_letter}' in well '{well_str}'.")
    if col_number not in COLS:
        raise ValueError(f"Invalid column number '{col_number}' in well '{well_str}'.")
    return ROWS.index(row_letter) * 12 + (col_number - 1)


def index_to_well(idx: int) -> tuple:
    if not (0 <= idx < TOTAL_WELLS):
        raise ValueError(f"Well index {idx} is out of range (0–95).")
    return ROWS[idx // 12], (idx % 12) + 1


def well_id_string(idx: int) -> str:
    r, c = index_to_well(idx)
    return f"{r}{c}"


# ---------------------------------------------------------------------------
# Inputs
# ---------------------------------------------------------------------------

def parse_args(arg_string: str) -> tuple:
    """"<pixl_output_folder>,<source_name>,<target_name>,<start_well>" -> (image_path, folder, source, target, start_well)."""
    parts = [p.strip() for p in arg_string.split(",")]
    if len(parts) != 4:
        raise ValueError(
            "Expected exactly 4 comma-delimited arguments:\n"
            "  pixl_output_folder, source_plate_name, target_plate_name, start_well\n"
            f"Got {len(parts)} part(s): {arg_string}")
    folder, source_name, target_name, start_well = parts
    if DRIVE_REMAP and len(folder) >= 2 and folder[1] == ":":
        folder = "X:" + folder[2:]
    if not os.path.isdir(folder):
        raise ValueError(f"Folder does not exist or is not a directory: '{folder}'")
    image = os.path.join(folder, "Original.png")
    if not os.path.isfile(image):
        cands = [os.path.join(folder, f) for f in os.listdir(folder) if f.lower().startswith("original") and f.lower().endswith((".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"))]
        if not cands:
            raise ValueError(f"Original.png not found in folder: '{folder}'")
        image = max(cands, key=os.path.getmtime)
    return image, folder, source_name, target_name, start_well


def read_agar_depth(folder):
    """Agar depth (mm) from Project.xml / SourcePlateColonySummary.csv / ProjectSummary.csv in the folder (None if unknown)."""
    f = os.path.join(folder, 'SourcePlateColonySummary.csv')
    if os.path.isfile(f):
        try:
            return float(list(csv.DictReader(open(f, encoding='utf-8-sig')))[0]['SourcePlate_AgarDepth'])
        except Exception:
            pass
    f = os.path.join(folder, 'Project.xml')
    if os.path.isfile(f):
        try:
            for el in ET.parse(f).getroot().iter('SourcePlate'):
                return float(el.attrib.get('AgarDepth'))
        except Exception:
            pass
    f = os.path.join(folder, 'ProjectSummary.csv')
    if os.path.isfile(f):
        try:
            return float(list(csv.DictReader(open(f, encoding='utf-8-sig')))[0]['SourcePlate_AgarDepth'])
        except Exception:
            pass
    return None


def load_image_bgr(path):
    img = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("image could not be decoded")
    return img


# ---------------------------------------------------------------------------
# Core processing
# ---------------------------------------------------------------------------

def detect_sector_colonies(img, agar):
    """One colony per Shimadzu-8 sector. Returns (picks_by_sector {0..7: candidate}, scale px/mm)."""
    cands, S = analyze(img, 'sbs8', agar)
    picks = select(cands, 0, per_sector=1, fill_low=True, min_sep=1.0) if cands else []
    return {c['sector']: c for c in picks}, S


def build_well_assignments(sector_map: dict, start_well: str, source_name: str) -> tuple:
    """Sector N -> well start+N (missing sectors skipped). Returns (assignments, return_string)."""
    NUM_SECTORS = 8
    start_idx = well_index(start_well)
    if start_idx + NUM_SECTORS > TOTAL_WELLS:
        raise ValueError(f"Starting at well {start_well} (index {start_idx}) with 8 sectors "
                         f"would exceed the 96-well plate boundary.")
    missing = sorted(set(range(NUM_SECTORS)) - set(sector_map))
    parts = []
    if missing:
        parts.append(source_name)
        for s in missing:
            parts += [f"Sector{s}", well_id_string(start_idx + s)]
    assignments = []
    for s in range(NUM_SECTORS):
        if s in sector_map:
            r, c = index_to_well(start_idx + s)
            col = sector_map[s]
            assignments.append({"sector": s, "colony_x": round(col["x_mm"], 3), "colony_y": round(col["y_mm"], 3),
                                "row": r, "col": c, "low": bool(col.get("lowConf"))})
    return assignments, ",".join(parts)


def write_rearray_csv(assignments, source_name, target_name, output_path):
    """Line 1: <source>,SBS,None,Source,,   Line 2: <target>,DWP,96,Target,,   then one row per colony."""
    with open(output_path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow([source_name, "SBS", "None", "Source", "", ""])
        w.writerow([target_name, "DWP", "96", "Target", "", ""])
        for a in assignments:
            first, second = (a["colony_y"], a["colony_x"]) if COORD_ORDER.upper() == 'YX' else (a["colony_x"], a["colony_y"])
            w.writerow([source_name, first, second, target_name, a["row"], a["col"]])


def draw(img, sector_map, S, path):
    out = img.copy(); f = img.shape[1] / REF_W; cx, cy = CX * f, CY * f
    for s, (x0, y0, x1, y1) in sector_boxes().items():
        col = (255, 255, 0) if s in sector_map else (0, 0, 255)
        a, b = (int(round(cx + S * x0)), int(round(cy + S * y0))), (int(round(cx + S * x1)), int(round(cy + S * y1)))
        cv2.rectangle(out, a, b, col, 2)
        cv2.putText(out, f"S{s}" + ("" if s in sector_map else " EMPTY"), (a[0] + 6, a[1] + 26), cv2.FONT_HERSHEY_SIMPLEX, .8, col, 2, cv2.LINE_AA)
    for s, c in sector_map.items():
        col = (0, 200, 255) if c.get('lowConf') else (0, 255, 0)
        p = (int(round(c['x'])), int(round(c['y'])))
        cv2.circle(out, p, max(int(round(c['r_px'])) + 5, 9), col, 2, cv2.LINE_AA)
        cv2.putText(out, str(s) + ("L" if c.get('lowConf') else ""), (p[0] + 10, p[1] - 10), cv2.FONT_HERSHEY_SIMPLEX, .8, col, 2, cv2.LINE_AA)
    ok, buf = cv2.imencode('.png', out)
    if ok: buf.tofile(path)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    if len(sys.argv) < 2:
        print('Usage: colony_picker_8_sector_momentum.exe "<pixl_output_folder>,<source_name>,<target_name>,<start_well>"', file=sys.stderr)
        sys.exit(1)
    arg_string = " ".join(sys.argv[1:]).strip().strip("'\"")
    try:
        image_path, output_dir, source_name, target_name, start_well = parse_args(arg_string)
    except ValueError as e:
        print(f"[ERROR] Argument parsing failed: {e}", file=sys.stderr); sys.exit(1)
    output_dir = os.path.abspath(output_dir)

    try:
        img = load_image_bgr(image_path)
        agar = read_agar_depth(output_dir)
        sector_map, S = detect_sector_colonies(img, agar)
    except Exception as e:
        print(f"[ERROR] Colony detection failed on '{image_path}': {e}", file=sys.stderr); sys.exit(1)

    try:
        assignments, return_string = build_well_assignments(sector_map, start_well, source_name)
    except ValueError as e:
        print(f"[ERROR] Well assignment failed: {e}", file=sys.stderr); sys.exit(1)

    output_file = os.path.join(output_dir, f"{source_name}_FinalRearray.csv")
    try:
        write_rearray_csv(assignments, source_name, target_name, output_file)
    except Exception as e:
        print(f"[ERROR] Could not write output file '{output_file}': {e}", file=sys.stderr); sys.exit(1)
    try:
        draw(img, sector_map, S, os.path.join(output_dir, f"{source_name}_picks.png"))
    except Exception:
        pass

    logs_dir = LOGS_DIR
    os.makedirs(logs_dir, exist_ok=True)
    location_file = os.path.join(logs_dir, f"{source_name}_Location.csv")
    try:
        with open(location_file, "w", newline="") as lf:
            csv.writer(lf).writerow([output_dir])
    except Exception as e:
        print(f"[ERROR] Could not write location file '{location_file}': {e}", file=sys.stderr); sys.exit(1)

    if return_string:
        try:
            with open(os.path.join(output_dir, f"{source_name}_rearray-logs.txt"), "w") as lf:
                lf.write(return_string)
        except Exception as e:
            print(f"[ERROR] Could not write log file: {e}", file=sys.stderr); sys.exit(1)

    run_log = os.path.join(logs_dir, "OmnitrayRearrayLog.txt")
    try:
        with open(run_log, "a") as rl:
            rl.write("=" * 60 + "\n")
            rl.write(f"Timestamp        : {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            rl.write(f"Source plate     : {source_name}\n")
            rl.write(f"Target plate     : {target_name}\n")
            rl.write(f"Start well       : {start_well}\n")
            rl.write(f"Working folder   : {output_dir}\n")
            rl.write(f"Image            : {image_path}\n")
            rl.write(f"Agar depth / scale: {agar} mm / {S:.3f} px/mm\n")
            rl.write(f"Output CSV       : {output_file}\n")
            rl.write(f"Location CSV     : {location_file}\n")
            rl.write(f"Sectors found    : {sorted(a['sector'] for a in assignments)}\n")
            low = [a['sector'] for a in assignments if a['low']]
            rl.write(f"Low-confidence   : {low if low else 'None'}\n")
            rl.write(f"Missing sectors  : {return_string if return_string else 'None'}\n\n")
    except Exception as e:
        print(f"[ERROR] Could not write run log '{run_log}': {e}", file=sys.stderr); sys.exit(1)


if __name__ == "__main__":
    main()
