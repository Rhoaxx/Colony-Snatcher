#!/usr/bin/env python3
r"""
colony_picker_momentum.py  —  PIXL Colony Picker, Momentum Integration   (v2: multi-scale detector)
=================================================================================================
Drop-in replacement for the previous colony_picker_momentum.py: same Momentum arguments, same
result.json / message.txt / last_run.txt files, same exit codes and the same rearray CSV format.
Only the colony detection changed (scale-space detector + learned "real colony" model, calibrated from
the agar depth), so it is far more robust to condensation, glare, bubbles and satellite colonies.

Designed for two-stage execution by Thermo Fisher Momentum 7.3 via ApplicationLauncher [Launch Application].
Arguments are received as a single comma-delimited string built by Momentum's DataBuilder step.

STAGE 1  —  detect
  detect,<tracking_path>,<plate_name>,<source_type>,<target_name>,<target_format>,<colony_count>,<mode>
    tracking_path   folder holding Original.png (and Project.xml / SourcePlateColonySummary.csv for the agar depth)
    source_type     SBS | Petri
    target_format   DWP_96 | SBS_96 | DWP_384
    colony_count    number of colonies required
    mode            strict  = only confident, isolated, round colonies
                    relaxed = strict picks first, then lower-confidence colonies (touching / irregular / small)
  Writes   <run_dir>\result.json   (full detection state for Stage 2)
           <run_dir>\message.txt   (operator prompt text)
           <run_dir>\<plate>_picks.png   (annotated image, numbered by well)
           C:\colony_picker\last_run.txt
  Exit codes: 0 target met   1 below target but >0 found   2 zero colonies   99 script error

STAGE 2  —  export
  export,<target_name>,<colony_count>,<run_folder_path>
  Reads result.json (no image reprocessing) and writes the rearray CSV(s) to the PIXL share and the run folder.
  Exit codes: 0 written   99 error

Requires: numpy, scipy, opencv-python   (pip install numpy scipy opencv-python)
"""

import csv
import io
import json
import math
import os
import re
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

try:
    import numpy as np
    import cv2
    from scipy import ndimage as ndi
    from scipy.spatial import cKDTree
except ImportError:
    _msg = "ERROR: Required packages missing. Run: pip install numpy scipy opencv-python"
    try:
        Path(r"C:\colony_picker\output").mkdir(parents=True, exist_ok=True)
        Path(r"C:\colony_picker\last_run.txt").write_text(str(Path(r"C:\colony_picker\output")))
        Path(r"C:\colony_picker\output\message.txt").write_text(_msg)
    except Exception:
        pass
    print(_msg, file=sys.stderr)
    sys.exit(99)

# ─────────────────────────────────────────────────────────────────────────────
# CONFIGURATION  (identical to the previous script; environment overrides are for offline testing only)
# ─────────────────────────────────────────────────────────────────────────────
OUTPUT_ROOT   = Path(os.environ.get('CP_OUTPUT_ROOT', r"C:\colony_picker\output"))
LAST_RUN_FILE = Path(os.environ.get('CP_LAST_RUN',    r"C:\colony_picker\last_run.txt"))
PIXL_SHARE    = Path(os.environ.get('CP_PIXL_SHARE',  r"X:\Users\Admin\PIXL_Rearray"))
WORKFLOW_SUBFOLDER = "ColonyDetection"
DRIVE_REMAP   = os.environ.get('CP_NO_DRIVE_REMAP') is None      # C: -> X: for the network-mapped PIXL drive
MIN_SEP_MM    = 1.0                                              # minimum distance between two picks

# ----------------------------------------------------------------------------- calibration & geometry
REF_W = 1728
CX, CY = 849.5, 865.5
DEFAULT_SCALE = {'petri': 10.83, 'sbs': 10.85, 'sbs8': 10.97}


def scale_for_agar(a):
    return 0.0229 * a + 10.7612


# Singer 'Shimadzu 8 Well' sector split: fractions of the 109 x 73 mm pickable area (the red dotted boxes in the PIXL image)
SHIM8_FX = [(0, .16), (.28, .44), (.54, .70), (.83, .99)]
SHIM8_FY = [(.03, .43), (.60, 1.0)]
SECTOR_COLS = [(-54.5 + 109 * a, -54.5 + 109 * b) for a, b in SHIM8_FX]
SECTOR_ROWS = [(-36.5 + 73 * a, -36.5 + 73 * b) for a, b in SHIM8_FY]
PETRI_R, PETRI_CY, SBS_X, SBS_Y = 39.5, 0.3, 54.5, 36.5


def sector_boxes():
    return {r * 4 + c: (SECTOR_COLS[c][0], SECTOR_ROWS[r][0], SECTOR_COLS[c][1], SECTOR_ROWS[r][1])
            for r in range(2) for c in range(4)}


def region_info(x, y, kind):
    """(inside, sector, edge_mm) for mm coordinates (arrays). sector = 0 on unsectored plates, -1 outside."""
    x = np.asarray(x, float); y = np.asarray(y, float)
    sec = -np.ones(x.shape, np.int16)
    if kind == 'petri':
        edge = PETRI_R - np.hypot(x, y - PETRI_CY); ins = edge >= 0; sec[ins] = 0
    elif kind == 'sbs':
        edge = np.minimum(SBS_X - np.abs(x), SBS_Y - np.abs(y)); ins = edge >= 0; sec[ins] = 0
    else:
        edge = np.full(x.shape, -1.0)
        for s, (x0, y0, x1, y1) in sector_boxes().items():
            e = np.minimum(np.minimum(x - x0, x1 - x), np.minimum(y - y0, y1 - y)); ins = e >= 0
            sec[ins] = s; edge = np.where(ins, e, edge)
    return sec >= 0, sec, edge


# ----------------------------------------------------------------------------- detection
SIGMAS = [1.6 * 2 ** (i / 2.0) for i in range(8)]
K_NOISE, K_BIG, BIG_FROM, STRIDE = 4.0, 2.0, 3, 3
GLINT_RATIO, GLINT_CENTER_RATIO = 2.6, 1.35


def gblur(img, sigma):
    """Gaussian blur with the exact kernel used by the JS engine (ksize = round(6*sigma+1)|1, reflect-101 borders)."""
    ks = int(round(sigma * 6 + 1)) | 1
    ks = max(ks, 3)
    r = (ks - 1) // 2
    k = np.exp(-((np.arange(ks) - r) ** 2) / (2.0 * sigma * sigma)).astype(np.float32)
    k /= k.sum()
    return cv2.sepFilter2D(img, cv2.CV_32F, k, k, borderType=cv2.BORDER_REFLECT_101)


def luminance(bgr):
    b, g, r = [bgr[..., i].astype(np.float32) for i in range(3)]
    return (0.299 * r + 0.587 * g + 0.114 * b).astype(np.float32)


def log_stack(gray):
    out = []
    for s in SIGMAS:
        if s >= 6.0:
            half = cv2.resize(gray, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
            g = gblur(half, s / 2)
            L = -(s * s) * cv2.Laplacian(g, cv2.CV_32F, ksize=1) / 4.0
            L = cv2.resize(L, (gray.shape[1], gray.shape[0]), interpolation=cv2.INTER_LINEAR)
        else:
            g = gblur(gray, s)
            L = -(s * s) * cv2.Laplacian(g, cv2.CV_32F, ksize=1)
        out.append(L)
    return np.stack(out)


def find_seeds(gray, mask):
    st = log_stack(gray)
    ms = mask[::STRIDE, ::STRIDE]
    vals = st[:, ::STRIDE, ::STRIDE][:, ms]
    med = np.median(vals, axis=1)
    noise = np.array([max(m - np.percentile(v, 15.87), 1e-3) for v, m in zip(vals, med)])
    kk = np.array([K_BIG if k >= BIG_FROM else K_NOISE for k in range(len(SIGMAS))])
    thr = (med + kk * noise)[:, None, None]
    nm = ndi.maximum_filter(st, size=(3, 3, 3), mode='nearest')
    peak = (st == nm) & (st > thr) & mask[None]
    ks, ys, xs = np.nonzero(peak)
    if len(ks) == 0:
        return np.zeros((0, 4))
    sg = np.array(SIGMAS)[ks]
    arr = np.c_[xs, ys, sg * 1.4142, st[ks, ys, xs] / noise[ks]]
    arr = arr[np.lexsort((-arr[:, 3], -arr[:, 2]))]
    n = len(arr); alive = np.ones(n, bool)
    tree = cKDTree(arr[:, :2])
    for i in range(n):
        if not alive[i]: continue
        rr = arr[i, 2]
        for j in tree.query_ball_point(arr[i, :2], r=rr * 1.1):
            if j <= i or not alive[j]: continue
            if arr[j, 2] < arr[i, 2] * 0.999: alive[j] = False
            elif np.hypot(*(arr[i, :2] - arr[j, :2])) < 0.7 * rr: alive[j] = False
    return arr[alive]


def hull_area(px, py, shape, tol=0.5):
    """Pixels inside the convex hull of the mask pixels (monotone chain; hull edge tolerance 0.5 px, as in the JS engine)."""
    pts = sorted(zip(px.tolist(), py.tolist()))
    def cross(o, a, b): return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    lower, upper = [], []
    for p in pts:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0: lower.pop()
        lower.append(p)
    for p in reversed(pts):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0: upper.pop()
        upper.append(p)
    hull = lower[:-1] + upper[:-1]
    if len(hull) < 3: return len(pts)
    Y, X = np.mgrid[0:shape[0], 0:shape[1]]
    ok = np.ones(shape, bool)
    for q in range(len(hull)):
        a, b = hull[q], hull[(q + 1) % len(hull)]
        el = math.hypot(b[0] - a[0], b[1] - a[1]) or 1.0
        ok &= ((b[0] - a[0]) * (Y - a[1]) - (b[1] - a[1]) * (X - a[0])) / el >= -tol
    return int(ok.sum())


def analyze(img_bgr, kind, agar=None, scale=None):
    """Detect candidate colonies. Returns (list of dict, scale_px_per_mm_in_this_image)."""
    H0, W0 = img_bgr.shape[:2]
    f = W0 / REF_W
    S = scale if scale else (scale_for_agar(agar) if agar is not None and np.isfinite(agar) else DEFAULT_SCALE[kind])
    S *= f
    cx0_, cy0_ = CX * f, CY * f
    yy, xx = np.mgrid[0:H0, 0:W0]
    ins, _, _ = region_info((xx - cx0_) / S, (yy - cy0_) / S, kind)
    if not ins.any():
        return [], S
    ys_, xs_ = np.nonzero(ins)
    M = 64
    cx0 = max(0, xs_.min() - M); cy0 = max(0, ys_.min() - M)
    cx1 = min(W0, xs_.max() + M + 1); cy1 = min(H0, ys_.max() + M + 1)
    cw = (cx1 - cx0) // 2 * 2; ch = (cy1 - cy0) // 2 * 2
    cx1, cy1 = cx0 + cw, cy0 + ch
    g2 = luminance(img_bgr)[cy0:cy1, cx0:cx1].copy()
    m2 = ins[cy0:cy1, cx0:cx1]
    gs = gblur(g2, 1.0)
    hp = gs - gblur(gs, 6.0)
    hv = hp[::STRIDE, ::STRIDE][m2[::STRIDE, ::STRIDE]]
    noise_px = 1.4826 * np.median(np.abs(hv - np.median(hv))) + 1e-3
    seeds = find_seeds(g2, m2)
    if len(seeds) == 0:
        return [], S
    H, W = gs.shape
    gx = cv2.Sobel(gs, cv2.CV_32F, 1, 0, ksize=3) / 8.0
    gy = cv2.Sobel(gs, cv2.CV_32F, 0, 1, ksize=3) / 8.0
    gm = np.hypot(gx, gy)
    cen = seeds[:, :2]; rr = seeds[:, 2]
    tree = cKDTree(cen)
    K3 = np.ones((3, 3), np.uint8)
    st4 = ndi.generate_binary_structure(2, 1)
    rows = []
    for i, (x, y, r0, _) in enumerate(seeds):
        x = int(x); y = int(y)
        win = int(2.8 * r0) + 4
        x0, x1 = max(0, x - win), min(W, x + win + 1)
        y0, y1 = max(0, y - win), min(H, y + win + 1)
        patch = gs[y0:y1, x0:x1]
        Y, X = np.mgrid[y0:y1, x0:x1]
        d64 = np.hypot(X - x, Y - y)
        wi = (d64 * d64 - r0 * r0).astype(np.float32).astype(np.float64)   # float32 rounding on ties, as in the JS engine
        di = d64.astype(np.float32)
        cell = np.ones(patch.shape, bool)
        for j in tree.query_ball_point([x, y], r=win * 1.6 + 30):
            if j == i: continue
            dj = (X - cen[j, 0]) ** 2 + (Y - cen[j, 1]) ** 2
            cell &= wi <= (dj - rr[j] ** 2)
        far = (di > 1.8 * r0) & (di < 2.8 * r0 + 3)
        fc = far & cell
        bgv = patch[fc] if fc.sum() > 10 else patch[far]
        bg = np.percentile(bgv, 25) if bgv.size else np.percentile(patch, 10)
        core = di <= max(0.5 * r0, 1.2)
        pk = float(np.percentile(patch[core], 75)); dl = pk - bg
        if not np.isfinite(dl) or dl < 2.0 * noise_px: continue
        lvl = bg + 0.5 * dl
        maxD = 2.4 * r0 + 2
        # specular glint guard (see colony_detect.js)
        dl_body, dl_top = dl, dl
        t0 = bg + max(5 * noise_px, 0.2 * dl)
        body = patch[(di <= maxD) & cell & (patch > t0)]
        glint = False; dl2 = dl; dl80 = dl
        if body.size >= 6:
            dl80 = np.percentile(body, 80) - bg; dl2 = np.percentile(body, 50) - bg
            glint = dl2 > 2.0 * noise_px and dl > GLINT_RATIO * dl2
        if dl2 > 2.0 * noise_px and dl2 < dl: dl_body = dl2
        dl_top = max(dl80, 1e-6)
        if glint:
            dl = dl2; pk = bg + dl2; lvl = bg + 0.5 * dl2
        m = (patch > lvl) & (di <= maxD)
        mc = m & cell
        lab, n = ndi.label(mc)
        cy_ = min(max(int(round(y - y0)), 0), lab.shape[0] - 1); cx_ = min(max(int(round(x - x0)), 0), lab.shape[1] - 1)
        l0 = lab[cy_, cx_]
        if l0 == 0:
            if n == 0: continue
            idx = ndi.distance_transform_edt(lab == 0, return_indices=True)[1]
            l0 = lab[idx[0][cy_, cx_], idx[1][cy_, cx_]]
        comp = ndi.binary_fill_holes(lab == l0)
        area = int(comp.sum())
        if area < 6: continue
        cu = comp.astype(np.uint8)
        ysc, xsc = np.nonzero(comp); mx, my = xsc.mean(), ysc.mean()
        cov = np.cov(np.vstack([xsc - mx, ysc - my]))
        ev = np.sort(np.linalg.eigvalsh(cov))[::-1]
        ar = float(np.sqrt(ev[0] / max(ev[1], 1e-6)))
        req = math.sqrt(area / math.pi)
        er4 = ndi.binary_erosion(comp, structure=st4, border_value=0)
        by, bx = np.nonzero(comp & ~er4)
        rad = np.hypot(bx - mx, by - my)
        radial_cv = float(rad.std() / (rad.mean() + 1e-6))
        dil = cv2.dilate(cu, K3) > 0
        ero = cv2.erode(cu, K3, borderType=cv2.BORDER_CONSTANT, borderValue=0) > 0
        ring_pix = dil & ~comp
        touch = float((ring_pix & (m & ~cell)).sum() / max(ring_pix.sum(), 1))
        gband = dil & ~ero
        edge_w = float(dl / (gm[y0:y1, x0:x1][gband].mean() + 1e-3) / max(req, 1.0))
        dist_out = ndi.distance_transform_edt(~comp)
        mwin = m2[y0:y1, x0:x1]
        rg = (dist_out > 0.25 * req + 1) & (dist_out < 0.9 * req + 3) & mwin
        ring_max = float((np.percentile(patch[rg], 95) - bg) / dl) if rg.sum() > 8 else 0.0
        solidity = float(area / max(hull_area(xsc, ysc, comp.shape), area))
        inscr = float(ndi.distance_transform_edt(comp).max() / max(req, 1.0))
        sat = float((g2[y0:y1, x0:x1][comp] >= 240).mean())
        fill = float((patch[di <= 0.5 * max(req, 1.5)].mean() - bg) / dl)
        clutter = float((np.percentile(bgv, 90) - np.percentile(bgv, 10)) / noise_px) if bgv.size > 10 else 0.0
        hal = (dist_out > 1.0) & (dist_out < 2.5 * req + 4) & mwin & cell
        halo = float((gm[y0:y1, x0:x1][hal] > 2 * noise_px).mean()) if hal.sum() > 10 else 0.0
        ccx, ccy = mx, my
        if dl > GLINT_CENTER_RATIO * dl_top:        # centre on the colony body, not on a specular highlight
            cm = (patch > bg + 0.5 * dl_body) & (di <= maxD) & cell
            s0 = None
            if cm[cy_, cx_]: s0 = (cy_, cx_)
            elif cm.any():
                idx = ndi.distance_transform_edt(~cm, return_indices=True)[1]
                s0 = (idx[0][cy_, cx_], idx[1][cy_, cx_])
            if s0 is not None:
                l2, _ = ndi.label(cm)
                reg = l2 == l2[s0]
                n2 = int(reg.sum())
                if 6 <= n2 <= 10 * area + 40:
                    yy2, xx2 = np.nonzero(reg); ccx, ccy = xx2.mean(), yy2.mean()
        gxp, gyp = ccx + x0 + cx0, ccy + y0 + cy0
        xm, ym = (gxp - cx0_) / S, (gyp - cy0_) / S
        ins1, sc1, ed1 = region_info(np.array([xm]), np.array([ym]), kind)
        rows.append(dict(x=float(gxp), y=float(gyp), r_seed=float(r0), r_px=float(req), r_mm=float(req / S),
                         snr=float(dl / noise_px), axis_ratio=ar, radial_cv=radial_cv, edge_w=edge_w, touch=touch,
                         ring_max=ring_max, solidity=solidity, inscr=inscr, sat=sat, fill=fill, clutter=clutter, halo=halo,
                         edge_mm=float(ed1[0]), sector=int(sc1[0]), x_mm=float(xm), y_mm=float(ym)))
    if not rows:
        return rows, S
    c2 = np.array([[r['x'], r['y']] for r in rows]); r2 = np.array([r['r_px'] for r in rows])
    t2 = cKDTree(c2)
    for k, r in enumerate(rows):
        nb = t2.query_ball_point(c2[k], r=r2[k] * 3 + 60)
        gaps = [np.hypot(*(c2[k] - c2[j])) - r2[k] - r2[j] for j in nb if j != k]
        r['gap_mm'] = float((min(gaps) if gaps else 50 * S) / S)
        r['dens3'] = int(sum(1 for j in t2.query_ball_point(c2[k], 3.0 * S) if j != k))
    return rows, S


# ----------------------------------------------------------------------------- scoring & selection
MODELS = json.loads(r'''{"model":{"features":["radial_cv","axis_ratio","edge_w","ring_max","gap_mm","dens3","edge_mm","snr","touch","solidity","inscr","fill","sat","clutter","halo"],"w":[-0.9878775430999591,-1.0134364704227854,-2.8306600593656235,-1.2807593006367421,0.09209367608957374,-0.02188336684771793,0.4537475070978126,1.8848809789266834,-0.7453924518594198,6.378692439709168,2.149773903399389,0.43545259223158345,-20.850216516818033,0.5344269612212657,-3.619654573189738],"b":-10.707421540896483},"real":{"features":["radial_cv","axis_ratio","edge_w","ring_max","touch","solidity","inscr","fill","sat","clutter","halo","lsnr","lr","gapc","dens","edge_mm"],"w":[-7.5541015538556175,-0.59887765516387,-1.6170540408517282,0.3105603354255493,-4.151849787949336,6.04888145500508,6.180937570918918,5.497938870123086,-26.823516894026717,-0.7499364911402016,-2.548623588832721,2.8196449302744075,1.8842610291981574,-0.08845211554608032,0.4330102458278428,0.4109233460283216],"b":-22.80555244659626}}''')
MODEL, REAL_MODEL = MODELS['model'], MODELS['real']
clipR = lambda v, a, b: min(b, max(a, v))


def feature_vector(c):
    return dict(radial_cv=clipR(c['radial_cv'], 0, .6), axis_ratio=clipR(c['axis_ratio'], 1, 3), edge_w=clipR(c['edge_w'], 0, 3),
                ring_max=clipR(c['ring_max'], -.3, 1.5), gap_mm=clipR(c['gap_mm'], -.5, 3), dens3=clipR(c['dens3'], 0, 30),
                edge_mm=clipR(c['edge_mm'], 0, 4.0), snr=math.log1p(clipR(c['snr'], 0, 120)), touch=clipR(c['touch'], 0, 1),
                solidity=clipR(c['solidity'], .5, 1), inscr=clipR(c['inscr'], .4, 1.05), fill=clipR(c['fill'], 0, 1.1),
                sat=clipR(c['sat'], 0, .5), clutter=math.log1p(clipR(c['clutter'], 0, 60)), halo=clipR(c['halo'], 0, .7))


def score(c):
    f = feature_vector(c)
    return MODEL['b'] + sum(w * f[n] for w, n in zip(MODEL['w'], MODEL['features']))


def p_real(c):
    f = dict(radial_cv=clipR(c['radial_cv'], 0, .6), axis_ratio=clipR(c['axis_ratio'], 1, 3), edge_w=clipR(c['edge_w'], 0, 3),
             ring_max=clipR(c['ring_max'], 0, 2), touch=clipR(c['touch'], 0, 1), solidity=clipR(c['solidity'], .5, 1),
             inscr=clipR(c['inscr'], .4, 1.05), fill=clipR(c['fill'], 0, 1.1), sat=clipR(c['sat'], 0, .5),
             clutter=math.log1p(clipR(c['clutter'], 0, 60)), halo=clipR(c['halo'], 0, .7), lsnr=math.log1p(clipR(c['snr'], 0, 300)),
             lr=math.log(clipR(c['r_px'], 1.5, 40)), gapc=clipR(c['gap_mm'], -.5, 2.5), dens=math.log1p(c['dens3']),
             edge_mm=clipR(c['edge_mm'], 0, 6))
    z = REAL_MODEL['b'] + sum(w * f[n] for w, n in zip(REAL_MODEL['w'], REAL_MODEL['features']))
    return 1 / (1 + math.exp(-z)) if z > -700 else 0.0


def is_artifact(c):
    return (c['halo'] > .45 or c['sat'] > .05 or c['fill'] < .75 or c['solidity'] < .80 or (c['clutter'] > 15 and c['ring_max'] > .6)
            or (c['ring_max'] > 1.0 and c['touch'] > .25) or (c['ring_max'] > .8 and c['touch'] > .2 and c['clutter'] > 8))


def tier_of(c):
    if is_artifact(c): return 4
    if (c['touch'] <= .02 and c['radial_cv'] <= .20 and c['axis_ratio'] <= 1.5 and c['snr'] >= 5 and c['edge_mm'] >= 1.0
            and c['gap_mm'] >= .15 and c['inscr'] >= .85 and c['solidity'] >= .93): return 1
    if (c['touch'] <= .15 and c['radial_cv'] <= .30 and c['axis_ratio'] <= 1.9 and c['snr'] >= 4 and c['edge_mm'] >= .8
            and c['inscr'] >= .78): return 2
    if c['radial_cv'] <= .45 and c['snr'] >= 3 and c['edge_mm'] >= .5: return 3
    return 4


def rank(cands, size_floor_frac=0.35, abs_floor=0.10):
    for c in cands:
        c['score'] = score(c); c['tier'] = tier_of(c); c['preal'] = p_real(c)
    g = {}
    for c in cands:
        if c['preal'] >= .5 and c['tier'] <= 2: g.setdefault(c['sector'], []).append(c['r_mm'])
    ref = {k: float(np.median(v)) for k, v in g.items() if len(v) >= 3}
    for c in cands: c['r_real_ref'] = ref.get(c['sector'])
    g1, g2 = {}, {}
    for c in cands:
        if c['tier'] == 1: g1.setdefault(c['sector'], []).append(c['r_mm'])
        if c['tier'] <= 2: g2.setdefault(c['sector'], []).append(c['r_mm'])
    allm = float(np.median([c['r_mm'] for c in cands])) if cands else 0
    for c in cands:
        s = c['sector']
        c['r_ref'] = float(np.median(g1[s])) if s in g1 else (float(np.median(g2[s])) if s in g2 else allm)
        c['too_small'] = c['r_mm'] < max(abs_floor, size_floor_frac * c['r_ref'])
        if c['too_small'] and c['tier'] < 4: c['tier'] = 3
    return cands



MIN_REAL, SATELLITE_W, DENSE_REAL, TIER_PENALTY, FILL_MIN_SNR, GAP_W, ROUND_W = 0.9, 3.0, 0.95, 1.5, 8, 0.5, 1.0
ALIVE_POP, ALIVE_REAL, ALIVE_SCORE, CROWD_N, CROWD_REAL = 4, 0.6, -3.6, 120, 0.5
LAWN_R, TINY_R, TINY_GAP, T1_REAL, T1_GAP, T1_R = 2.0, 0.3, 0.25, 0.8, 0.25, 0.3
CROWD_W, CROWD_FROM = 0.1, 6          # a colony inside a tight group (many neighbours within ~3 mm) ranks lower


def round_pen(c):
    return ROUND_W * (max(0, c['axis_ratio'] - 1.10) * 4 + max(0, c['radial_cv'] - 0.10) * 6)


def _pick_from(pool, k, out, max_tier, min_sep):
    def sat_pen(c):
        if not c['r_real_ref']: return 0.0
        return SATELLITE_W * max(0.0, math.log(c['r_real_ref'] / max(c['r_mm'], .05)) - math.log(1.6))
    def adj(c):
        return (c['score'] - sat_pen(c) - TIER_PENALTY * (c['tier'] - 1) - round_pen(c) + GAP_W * min(2.5, max(-.5, c['gap_mm']))
                - CROWD_W * max(0, c['dens3'] - CROWD_FROM))
    taken = {id(o) for o in out}
    for c in sorted([c for c in pool if c['tier'] <= max_tier and id(c) not in taken], key=adj, reverse=True):
        if len(out) >= k: break
        if all(math.hypot(c['x_mm'] - o['x_mm'], c['y_mm'] - o['y_mm']) >= min_sep for o in out): out.append(c)
    return out


def select(cands, n, per_sector=None, sectors=None, fill_low=False, min_sep=1.0, min_real=MIN_REAL,
           min_score=-1.0, fill_min=-2.0, dense_fallback=True):
    """per_sector: int or list (colonies per sector) -> sector mode; otherwise the n best over the plate."""
    rank(cands)
    for c in cands: c['lowConf'] = False

    def strict_ok(c):
        return c['preal'] >= min_real and (c['score'] >= min_score or (c['tier'] == 1 and c['score'] >= fill_min))

    def fill_ok(c):
        return (c['preal'] >= .7 and c['score'] >= fill_min and c['snr'] >= FILL_MIN_SNR and c['axis_ratio'] <= 1.6 and c['solidity'] >= .85)

    if per_sector is not None:
        secs = sectors if sectors is not None else list(range(8))
        chosen = []
        for s in secs:
            k = per_sector[s] if isinstance(per_sector, (list, tuple)) else per_sector
            if k <= 0: continue
            pool = [c for c in cands if c['sector'] == s]
            # sector-level evidence: a growing sector holds a population of confident colonies / many candidates
            pop = sum(1 for c in pool if c['preal'] >= .5 and c['tier'] <= 2)
            alive, crowded = pop >= ALIVE_POP, len(pool) >= CROWD_N
            if pop < ALIVE_POP:      # lone tiny specks touching a neighbour (dust, droplets, glints) are not colonies
                pool = [c for c in pool if not (c['r_mm'] < TINY_R and c['gap_mm'] < TINY_GAP)]
            out = _pick_from([c for c in pool if strict_ok(c)], k, [], 2, min_sep)
            if len(out) < k:         # clearly isolated, round, tier-1 colony with slightly lower confidence
                _pick_from([c for c in pool if c['tier'] == 1 and c['preal'] >= T1_REAL and c['score'] >= fill_min
                            and c['gap_mm'] >= T1_GAP and c['r_mm'] >= T1_R], k, out, 1, min_sep)
            if not out and (alive or crowded):   # populated sector, no clean colony: relax confidence gate, flag LOW
                pr = ALIVE_REAL if alive else CROWD_REAL
                _pick_from([c for c in pool if c['preal'] >= pr and c['score'] >= ALIVE_SCORE and c['snr'] >= 5], k, out, 3, min_sep)
                for c in out: c['lowConf'] = True
            if len(out) < k and fill_low:
                b = len(out)
                _pick_from([c for c in pool if fill_ok(c)], k, out, 3, min_sep)
                for c in out[b:]: c['lowConf'] = True
            if len(out) < k and dense_fallback:   # crowded / confluent sector: best-separated confident colonies, LOW
                b = len(out)
                _pick_from([c for c in pool if c['preal'] >= DENSE_REAL and c['sat'] <= .05 and c['fill'] >= .75 and c['solidity'] >= .8
                            and c['edge_mm'] >= 1.0 and c['halo'] <= .2 and not (c['ring_max'] > 1.0 and c['touch'] > .25)], k, out, 4, min_sep)
                for c in out[b:]: c['lowConf'] = True
            if not out and dense_fallback:        # worst case (confluent lawn): best isolated large lobe, LOW
                _pick_from([c for c in pool if c['r_mm'] >= LAWN_R and c['snr'] >= 6 and c['solidity'] >= .8 and c['fill'] >= .75
                            and c['halo'] <= .2 and c['sat'] <= .05 and c['edge_mm'] >= 1.5 and c['axis_ratio'] <= 1.9
                            and c['touch'] <= .1 and c['gap_mm'] >= .4 and c['ring_max'] <= 1.0], k, out, 4, min_sep)
                for c in out: c['lowConf'] = True
            chosen += out
        return chosen
    pool = [c for c in cands if c['sector'] >= 0]
    out = _pick_from([c for c in pool if strict_ok(c)], n, [], 2, min_sep)
    if len(out) < n and fill_low:
        b = len(out)
        _pick_from([c for c in pool if fill_ok(c)], n, out, 3, min_sep)
        for c in out[b:]: c['lowConf'] = True
    return out


# ----------------------------------------------------------------------------- last resort: isolated dots in a lawn
# Dense / confluent growth (e.g. flat BL21 colonies) leaves no colony the candidate detector can trust. For a sector that
# is *still* empty after every rule above AND shows lawn texture, take the best small bright dot that sits in a clear gap
# of the lawn (surrounded by visible agar). Texture gate: median |DoG(2px,6px)| of the sector luminance; confluent growth
# scores >= 1.25, empty agar / bubbles / dust / marker ink <= 0.7 on every plate checked.
LAWN_TEX_MIN, DOT_C_MIN, DOT_ABS_MIN, DOT_RING_P75, DOT_MARGIN_MM = 1.0, 0.35, 4.0, 0.50, 1.5
DOT_MAX_AREA, DOT_MAX_ASPECT, DOT_LOC_MIN = 100, 1.7, 6.0
# (c_min, local contrast, moat P75 cap, outer P75 cap, max area px, max aspect): strict level first, then relaxed
DOT_LEVELS = [(0.35, 6.0, 0.75, 0.95, 100, 1.7), (0.30, 4.0, 0.95, 1.10, 140, 2.0)]


def sector_texture(img_bgr, S, box, g=None):
    f = img_bgr.shape[1] / REF_W
    g = luminance(img_bgr) if g is None else g
    cx, cy = CX * f, CY * f
    x0, y0, x1, y1 = box
    sub = g[int(cy + S * y0):int(cy + S * y1), int(cx + S * x0):int(cx + S * x1)]
    if sub.size == 0: return 0.0
    dg = gblur(sub, 2.0 * f) - gblur(sub, 6.0 * f)
    return float(np.median(np.abs(dg)))


def dot_fallback(img_bgr, S, box, taken=(), min_sep=1.0, want=1):
    """Best isolated dot(s) in a lawn sector. S = px/mm in this image. Returns candidate-like dicts (lowConf).
    Dots are judged at fine scale (sigma 1.2 px): a small bright blob whose immediate surroundings (0.3-0.55 mm) are dark agar,
    and whose wider surroundings (0.55-0.9 mm) are not part of a big mass. Ranking = peak contrast - moat brightness - 0.5 * outer brightness."""
    f = img_bgr.shape[1] / REF_W
    g = luminance(img_bgr)
    if sector_texture(img_bgr, S, box, g) < LAWN_TEX_MIN: return []
    cx, cy = CX * f, CY * f
    x0, y0, x1, y1 = box
    X0, X1, Y0, Y1 = int(cx + S * x0), int(cx + S * x1), int(cy + S * y0), int(cy + S * y1)
    pad = int(14 * f) + 2
    A0, B0 = max(0, Y0 - pad), max(0, X0 - pad)
    g = g[A0:Y1 + pad, B0:X1 + pad]
    g1 = gblur(g, 1.2 * f)
    sub = g1[Y0 - A0:Y1 - A0, X0 - B0:X1 - B0]
    lo, hi = np.percentile(sub, 3), np.percentile(sub, 92)
    rng = max(hi - lo, 1e-3)
    mx = g1 == ndi.maximum_filter(g1, size=max(3, int(5 * f) | 1))
    ys, xs = np.nonzero(mx)
    R = int(round(12 * f)); yy, xx = np.mgrid[-R:R + 1, -R:R + 1]; rr = np.hypot(xx, yy)
    moat = (rr >= 3 * f) & (rr <= 6 * f); outer = (rr > 6 * f) & (rr <= 10 * f); core = rr <= 4 * f
    mar = DOT_MARGIN_MM
    res = []
    for c_min, loc_min, moat_cap, out_cap, a_max, asp_max in DOT_LEVELS:   # strict first; relax only if nothing qualifies
        out = []
        for y, x in zip(ys, xs):
            mxm, mym = (x + B0 - cx) / S, (y + A0 - cy) / S
            if not (x0 + mar <= mxm <= x1 - mar and y0 + mar <= mym <= y1 - mar): continue
            if y < R or x < R or y + R + 1 > g1.shape[0] or x + R + 1 > g1.shape[1]: continue
            c = (g1[y, x] - lo) / rng
            if c < c_min or (g1[y, x] - lo) < DOT_ABS_MIN: continue
            if g[y - R:y + R + 1, x - R:x + R + 1][core].max() >= 245: continue          # glint / saturated
            pt = g1[y - R:y + R + 1, x - R:x + R + 1]
            mv, ov = (pt[moat] - lo) / rng, (pt[outer] - lo) / rng
            mmed, mp75, op75 = float(np.median(mv)), float(np.percentile(mv, 75)), float(np.percentile(ov, 75))
            if (c - mmed) * rng < loc_min or mp75 > moat_cap or op75 > out_cap: continue
            medr = np.median(pt[moat]); thr = medr + 0.65 * (g1[y, x] - medr)
            lab, _ = ndi.label(pt >= thr); reg = lab == lab[R, R]; area = int(reg.sum())
            if area < 5 * f * f or area > a_max * f * f: continue
            ry, rx = np.nonzero(reg)
            ev = np.linalg.eigvalsh(np.cov(np.vstack([rx, ry]))) if area > 2 else np.array([1., 1.])
            aspect = float(math.sqrt(max(ev[1], 1e-6) / max(ev[0], 1e-6)))
            if aspect > asp_max: continue
            key = c - mmed - 0.5 * op75 - 0.6 * (aspect - 1) + 0.25 * min(area, 60) / 60.0
            out.append(dict(x=float(x + B0), y=float(y + A0), x_mm=float(mxm), y_mm=float(mym), r_px=3.5 * f, r_mm=3.5 * f / S,
                            dot_c=float(c), dot_ring=mp75, dot_med=mmed, dot_out=op75, dot_aspect=aspect, dot_area=area, key=float(key),
                            lowConf=True, dot=True, preal=0.0, score=0.0, tier=4, sector=-1))
        out.sort(key=lambda q: q['key'], reverse=True)
        res = []
        for q in out:
            if all(math.hypot(q['x_mm'] - o['x_mm'], q['y_mm'] - o['y_mm']) >= min_sep for o in list(taken) + res):
                res.append(q)
                if len(res) >= want: break
        if res: return res
    return []


# ─────────────────────────────────────────────────────────────────────────────
# UTILITIES  (unchanged)
# ─────────────────────────────────────────────────────────────────────────────

def make_run_dir(plate_name: str) -> Path:
    ts      = time.strftime('%Y%m%d_%H%M%S')
    run_dir = OUTPUT_ROOT / f"{plate_name}_{ts}"
    run_dir.mkdir(parents=True, exist_ok=True)
    LAST_RUN_FILE.parent.mkdir(parents=True, exist_ok=True)
    LAST_RUN_FILE.write_text(str(run_dir))
    return run_dir


def write_message(text: str, run_dir: Path = None):
    target = run_dir if run_dir else OUTPUT_ROOT
    target.mkdir(parents=True, exist_ok=True)
    (target / "message.txt").write_text(text)


def abort(msg: str, code: int = 99, run_dir: Path = None):
    write_message(f"ERROR: {msg}", run_dir)
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(code)


def parse_args(argv):
    """Parse the Momentum DataBuilder string (see module docstring). Unchanged from the previous script."""
    if len(argv) < 2:
        abort("No arguments received. Expected comma-delimited string from DataBuilder.")
    tokens = [a.strip().strip('"') for a in argv[1:]]
    if not tokens:
        abort("Argument string is empty.")
    if len(tokens) == 1 and ',' in tokens[0]:
        tokens = [t.strip().strip('"') for t in tokens[0].split(',')]
    stage = tokens[0].lower()

    if stage == 'detect':
        path_parts = []
        tail_start = len(tokens)
        for i in range(1, len(tokens)):
            path_parts.append(tokens[i])
            if tokens[i].lower().rstrip('\\').endswith('colonydetection'):
                tail_start = i + 1
                break
        if not path_parts:
            abort(f"Could not find tracking path in arguments: {tokens!r}")
        tracking_path = ' '.join(path_parts)
        if DRIVE_REMAP and tracking_path[:2].upper() == 'C:' and not os.path.exists(tracking_path):   # remap only if the path is not reachable as given
            tracking_path = 'X:' + tracking_path[2:]
        tail = tokens[tail_start:]
        if len(tail) < 6:
            abort(f"Stage 'detect' needs 6 fields after path (plate_name, source_type, target_name, target_format, "
                  f"colony_count, mode), got {len(tail)}.\n  path={tracking_path!r}\n  tail={tail!r}")
        try:
            colony_count = int(tail[4])
        except ValueError:
            abort(f"colony_count must be an integer, got {tail[4]!r}")
        return {'stage': 'detect', 'tracking_path': tracking_path, 'plate_name': tail[0], 'source_type': tail[1].upper(),
                'target_name': tail[2], 'target_format': tail[3], 'colony_count': colony_count, 'mode': tail[5].lower()}

    elif stage == 'export':
        raw = ','.join(tokens)
        try:
            parts = next(csv.reader(io.StringIO(raw), skipinitialspace=True, quotechar='"'))
            parts = [p.strip() for p in parts]
        except Exception:
            parts = tokens
        if len(parts) < 4:
            abort(f"Stage 'export' requires 4 fields, got {len(parts)}: {raw}")
        try:
            colony_count = int(parts[2])
        except ValueError:
            abort(f"colony_count must be an integer, got {parts[2]!r}")
        return {'stage': 'export', 'target_name': parts[1], 'colony_count': colony_count, 'run_folder_path': parts[3]}
    else:
        abort(f"Unknown stage '{stage}'. Expected 'detect' or 'export'.")


def find_image(tracking_path: str) -> Path:
    """Resolve Original.png from the PIXL_Output_Path variable (unchanged)."""
    base = Path(tracking_path)
    if not base.exists():
        abort(f"Tracking path not found: {base}")
    image_path = base / "Original.png"
    if image_path.is_file():
        return image_path
    image_path = base / WORKFLOW_SUBFOLDER / "Original.png"
    if image_path.is_file():
        return image_path
    candidates = list(base.rglob("Original*.png"))
    if not candidates:
        candidates = list(base.rglob("*.png"))
    if not candidates:
        abort(f"No image found under: {base}")
    return max(candidates, key=lambda p: p.stat().st_mtime)


def read_agar_depth(folder: Path):
    """Agar depth (mm) from the PIXL tracking files next to the image (Project.xml / SourcePlateColonySummary.csv / ProjectSummary.csv)."""
    for d in (folder, folder.parent):
        f = d / 'SourcePlateColonySummary.csv'
        if f.is_file():
            try:
                r = list(csv.DictReader(open(f, encoding='utf-8-sig')))
                return float(r[0]['SourcePlate_AgarDepth'])
            except Exception:
                pass
        f = d / 'Project.xml'
        if f.is_file():
            try:
                for el in ET.parse(f).getroot().iter('SourcePlate'):
                    return float(el.attrib.get('AgarDepth'))
            except Exception:
                pass
        f = d / 'ProjectSummary.csv'
        if f.is_file():
            try:
                r = list(csv.DictReader(open(f, encoding='utf-8-sig')))
                return float(r[0]['SourcePlate_AgarDepth'])
            except Exception:
                pass
    return None


def load_image_bgr(path: Path):
    data = np.fromfile(str(path), dtype=np.uint8)          # works with any path characters on Windows
    img = cv2.imdecode(data, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("image could not be decoded")
    return img


# ─────────────────────────────────────────────────────────────────────────────
# WELL ASSIGNMENT  (unchanged)
# ─────────────────────────────────────────────────────────────────────────────

def available_wells(target_format: str) -> list:
    rows = 16 if '384' in target_format else 8
    cols = 24 if '384' in target_format else 12
    return [chr(65 + r) + str(c) for r in range(rows) for c in range(1, cols + 1)]


def assign_wells(colonies: list, target_format: str, colony_count: int, start_well: str = 'A1') -> list:
    wells = available_wells(target_format)
    cap = len(wells)
    start_idx = 0
    if start_well and start_well != 'A1':
        try:
            start_idx = wells.index(start_well.upper())
        except ValueError:
            start_idx = 0
    result, well_idx, plate = [], start_idx, 1
    for colony in colonies[:colony_count]:
        if well_idx >= cap:
            well_idx = 0
            plate += 1
        entry = dict(colony)
        entry['well'] = wells[well_idx]
        entry['plate_index'] = plate
        result.append(entry)
        well_idx += 1
    return result


# ─────────────────────────────────────────────────────────────────────────────
# DETECTION + SELECTION
# ─────────────────────────────────────────────────────────────────────────────

def select_colonies(cands, target, mode):
    """strict: confident colonies only.  relaxed: strict first, then lower-confidence colonies, then any non-artifact colony."""
    if mode == 'relaxed':
        picks = select(cands, target, fill_low=True, min_sep=MIN_SEP_MM)
        if len(picks) < target:
            taken = {id(c) for c in picks}
            rest = [c for c in cands if id(c) not in taken and c['sector'] >= 0 and c['tier'] <= 3 and c['snr'] >= 4 and c['preal'] >= 0.3 and c['r_mm'] <= 2.5 and c['axis_ratio'] <= 2.0]
            rest.sort(key=lambda c: c['score'] + 0.5 * min(2.5, max(-.5, c['gap_mm'])), reverse=True)
            for c in rest:
                if len(picks) >= target: break
                if all(math.hypot(c['x_mm'] - o['x_mm'], c['y_mm'] - o['y_mm']) >= MIN_SEP_MM * 0.6 for o in picks):
                    c['lowConf'] = True; c['relaxed'] = True
                    picks.append(c)
        return picks
    return select(cands, target, fill_low=False, min_sep=MIN_SEP_MM)


def annotate(img, assigned, path, scale):
    out = img.copy()
    for c in assigned:
        col = (0, 200, 255) if c.get('lowConf') else (0, 255, 0)
        p = (int(round(c['x'])), int(round(c['y'])))
        cv2.circle(out, p, max(int(round(c['r_px'])) + 5, 9), col, 2, cv2.LINE_AA)
        cv2.putText(out, c['well'], (p[0] + 10, p[1] - 10), cv2.FONT_HERSHEY_SIMPLEX, .6, (0, 0, 0), 3, cv2.LINE_AA)
        cv2.putText(out, c['well'], (p[0] + 10, p[1] - 10), cv2.FONT_HERSHEY_SIMPLEX, .6, col, 1, cv2.LINE_AA)
    ok, buf = cv2.imencode('.png', out)
    if ok:
        buf.tofile(str(path))


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 1 — DETECT
# ─────────────────────────────────────────────────────────────────────────────

def run_detect(params: dict):
    run_dir = make_run_dir(params['plate_name'])
    image_path = find_image(params['tracking_path'])
    try:
        img = load_image_bgr(image_path)
    except Exception as e:
        abort(f"Cannot open image '{image_path}': {e}", run_dir=run_dir)

    kind = 'petri' if params['source_type'] == 'PETRI' else 'sbs'
    agar = read_agar_depth(image_path.parent)
    try:
        cands, S = analyze(img, kind, agar)
    except Exception as e:
        abort(f"Colony detection failed: {e}", run_dir=run_dir)

    target, mode = params['colony_count'], params['mode']
    selected = select_colonies(cands, target, mode) if cands else []
    n_found = len(selected)
    assigned = assign_wells(selected, params['target_format'], target, start_well='A1')

    f = img.shape[1] / REF_W
    plate_cx, plate_cy = CX * f, CY * f
    result = {
        'timestamp':     time.strftime('%Y-%m-%dT%H:%M:%S'),
        'image_path':    str(image_path),
        'plate_name':    params['plate_name'],
        'source_type':   params['source_type'],
        'target_name':   params['target_name'],
        'target_format': params['target_format'],
        'colony_count':  target,
        'mode':          mode,
        'n_found':       n_found,
        'agar_depth_mm': agar,
        'calibration': {'plate_cx': plate_cx, 'plate_cy': plate_cy, 'px_per_mm': S,
                        'bounds': {'r1': 0, 'r2': img.shape[0], 'c1': 0, 'c2': img.shape[1]}},
        'colonies': [
            {'well': c['well'], 'plate_index': c['plate_index'],
             'x_mm': round(c['x_mm'], 8), 'y_mm': round(c['y_mm'], 8),
             'quality': round(c['preal'], 4), 'relaxed': bool(c.get('relaxed', False) or c.get('lowConf', False))}
            for c in assigned],
    }
    (run_dir / 'result.json').write_text(json.dumps(result, indent=2))
    try:
        annotate(img, assigned, run_dir / f"{params['plate_name']}_picks.png", S)
    except Exception:
        pass

    n_low = sum(1 for c in assigned if c.get('lowConf'))
    if n_found == 0:
        write_message(f"No colonies detected on plate '{params['plate_name']}'. Check plate image and try again.", run_dir)
        return 2
    if n_found >= target:
        write_message(f"{n_found} of {target} colonies found on '{params['plate_name']}'. Ready to proceed with rearray."
                      + (f" ({n_low} lower-confidence)" if n_low else ""), run_dir)
        return 0
    write_message(f"Only {n_found} of {target} colonies found on '{params['plate_name']}' ({mode} mode). "
                  f"Proceed with {n_found} colonies, or abort and retry?", run_dir)
    return 1


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 2 — EXPORT  (unchanged)
# ─────────────────────────────────────────────────────────────────────────────

def run_export(params: dict):
    run_dir = Path(params['run_folder_path'])
    result_path = run_dir / 'result.json'
    if not run_dir.is_dir():
        abort(f"Run folder not found: {run_dir}")
    if not result_path.is_file():
        abort(f"result.json not found in {run_dir} — Stage 1 (detect) must run first.", run_dir=run_dir)
    try:
        result = json.loads(result_path.read_text())
    except Exception as e:
        abort(f"Cannot read result.json: {e}", run_dir=run_dir)

    colonies, target_name = result['colonies'], result['target_name']
    target_format, plate_name, source_type = result['target_format'], result['plate_name'], result['source_type']
    if not colonies:
        abort("No colonies in result.json — nothing to export.")
    if not PIXL_SHARE.exists():
        abort(f"PIXL network share not reachable: {PIXL_SHARE}")

    plates: dict = {}
    for c in colonies:
        plates.setdefault(c['plate_index'], []).append(c)

    src_type_str = 'Petri' if source_type == 'PETRI' else 'SBS'
    tt, tw = target_format.split('_')
    written = []
    for idx, plate_cols in sorted(plates.items()):
        fname = f"{target_name}_plate_{idx}_RearrayFile.csv"
        lines = [f"{plate_name},{src_type_str},None,Source,,", f"{target_name}_plate_{idx},{tt},{tw},Target,,"]
        for c in plate_cols:
            m = re.match(r'^([A-Z])(\d+)$', c['well'])
            if not m:
                continue
            lines.append(f"{plate_name},{c['y_mm']:.8f},{c['x_mm']:.8f},{target_name}_plate_{idx},{m.group(1)},{m.group(2)}")
        csv_text = '\n'.join(lines) + '\n'
        pixl_path = PIXL_SHARE / fname
        try:
            pixl_path.write_text(csv_text)
            written.append(str(pixl_path))
        except Exception as e:
            abort(f"Cannot write to PIXL share '{pixl_path}': {e}", run_dir=run_dir)
        (run_dir / fname).write_text(csv_text)

    write_message(f"Rearray file(s) written for '{plate_name}': " + ", ".join(written), run_dir)
    return 0


def main():
    params = parse_args(sys.argv)
    try:
        if params['stage'] == 'detect':
            code = run_detect(params)
        else:
            code = run_export(params)
    except SystemExit:
        raise
    except Exception as e:                      # never leave Momentum without a message
        import traceback
        traceback.print_exc()
        abort(f"Unexpected error: {e}")
    sys.exit(code)


if __name__ == '__main__':
    main()
