# Momentum colony tools v2 (new detection algorithm)

Two drop-in replacements. Same Momentum arguments, same output files, same exit codes.

| Script | Replaces | Build to |
|---|---|---|
| `colony_picker_momentum.py` | previous `colony_picker_momentum.py` (large number of colonies, no sectoring) | `colony_picker_momentum.exe` |
| `colony_picker_8_sector_momentum.py` | previous `pixl_rearray_processor.py` / `OmnitrayRearray.exe` (Shimadzu 8-sector, 1 colony per sector) | `colony_picker_8_sector_momentum.exe` |

Both need: `pip install numpy scipy opencv-python` (pandas / Pillow are no longer needed).

Build (on the Momentum PC, Windows):

    pip install pyinstaller numpy scipy opencv-python
    pyinstaller --onefile --collect-submodules scipy --hidden-import scipy._external.array_api_compat.numpy.fft --name colony_picker_momentum colony_picker_momentum.py
    pyinstaller --onefile --collect-submodules scipy --hidden-import scipy._external.array_api_compat.numpy.fft --name colony_picker_8_sector_momentum colony_picker_8_sector_momentum.py

## colony_picker_momentum
Arguments, `result.json`, `message.txt`, `last_run.txt`, exit codes 0/1/2/99, stage 2 export and the CSV format are unchanged.
* Reads `Original.png` from the tracking path; the agar depth (image calibration) comes from `Project.xml`,
  `SourcePlateColonySummary.csv` or `ProjectSummary.csv` next to it (default calibration if none is found).
* `strict`: only confident isolated round colonies. `relaxed`: strict first, then lower-confidence colonies, then any
  remaining non-artifact colony. Lower-confidence picks have `"relaxed": true` in `result.json` and are mentioned in `message.txt`.
* New extra output in the run folder: `<plate>_picks.png` (picks labelled by well).

## colony_picker_8_sector_momentum
Call is unchanged: `colony_picker_8_sector_momentum.exe "<folder>,<source>,<target>,<start_well>"`. The folder now only needs `Original.png`
(no .tsv / Project.xml needed; Project.xml or SourcePlateColonySummary.csv are used for the agar depth if present).
* Detects colonies inside the 8 Shimadzu 8-Well rectangles (same sectors the PIXL draws) and picks one per sector; sectors
  without a clean colony are topped up with lower-confidence colonies, and a sector with nothing acceptable stays empty.
* Outputs unchanged: `<Source>_FinalRearray.csv` (sector N -> well start+N, missing sectors skipped), `<Source>_rearray-logs.txt`
  (only when sectors are missing, `Source,Sector<N>,<Well>,...`), `<Source>_Location.csv` and `OmnitrayRearrayLog.txt` in
  `C:\colony_picker\OmnitrayRearray\Logs` (the run log now also lists low-confidence sectors).
* Extra: `<Source>_picks.png` (sector rectangles, picks, empty sectors in red) in the folder.

## Dense-lawn pick (8-sector tool)
If a sector is still empty after all normal rules AND shows confluent-lawn texture (e.g. flat BL21 growth), the tool picks the
best small round dot sitting in a gap of the lawn. These are flagged LOW in the log (`Dense-lawn picks`), drawn magenta with a
small `D` dot in `<Source>_picks.png`. Empty / bubble / dust sectors do not have lawn texture, so they are still reported missing.
Dots are judged at fine scale: a small bright blob whose immediate surroundings are dark agar and that is not part of a big mass.
Extra images for manual curation (8-sector tool, written next to `<Source>_picks.png`):
* `<Source>_processed.png` - whole plate, contrast-stretched grayscale, small dot + sector number on each pick.
* `<Source>_sector0.png` ... `<Source>_sector7.png` - each full sector (4x) in the same view, with mm ticks (x / y) on the edges and the pick as a small dot
  (magenta = dense-lawn, green = normal, orange = low-confidence). Sector N = HTML S(N+1).
* `<Source>_closeups.png` - one close-up per sector with a centre dot.

## Coordinate order in the CSV
Confirmed on the PIXL: the rearray CSV must be **Y, X** (matching the .tsv template). Both tools now write Y_mm, X_mm.
(The old processor wrote X, Y; the 8-sector tool's default is now YX. Env var `RP_COORD_ORDER=XY` restores the old order.)

## Testing without Momentum
Environment overrides (testing only): `CP_OUTPUT_ROOT`, `CP_LAST_RUN`, `CP_PIXL_SHARE`, `CP_NO_DRIVE_REMAP=1`, `RP_LOGS_DIR`, `RP_NO_DRIVE_REMAP=1`.
