@echo off
:: ============================================================
:: install_colony_picker_momentum.bat
:: Builds colony_picker_momentum.exe from colony_picker_momentum.py and installs it into C:\colony_picker\colony_picker_momentum
::
:: Requirements:
::   - Python 3.8+ on the system PATH
::   - Internet access (pip installs dependencies)
::   - colony_picker_momentum.py in the same folder as this script
:::: ============================================================

setlocal EnableDelayedExpansion

set INSTALL_DIR=C:\colony_picker\colony_picker_momentum
set SCRIPT_NAME=colony_picker_momentum
set EXE_NAME=colony_picker_momentum

set BAT_DIR=%~dp0
if "!BAT_DIR:~-1!"=="\" set BAT_DIR=!BAT_DIR:~0,-1!

echo.
echo ============================================================
echo  %EXE_NAME% Installer
echo ============================================================
echo  Installer folder:  !BAT_DIR!
echo  Install directory: %INSTALL_DIR%
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python was not found on the PATH.
    echo         Please install Python 3.8+ and add it to PATH.
    pause
    exit /b 1
)

if not exist "%INSTALL_DIR%" (
    echo Creating directory %INSTALL_DIR% ...
    mkdir "%INSTALL_DIR%"
    if errorlevel 1 (
        echo [ERROR] Could not create %INSTALL_DIR%. Check permissions.
        pause
        exit /b 1
    )
) else (
    echo Install directory already exists, continuing...
)

set SOURCE_PY=!BAT_DIR!\%SCRIPT_NAME%.py
if /I "!BAT_DIR!"=="%INSTALL_DIR%" (
    echo Source file is already in the install directory, skipping copy.
) else (
    if not exist "!SOURCE_PY!" (
        echo [ERROR] Cannot find %SCRIPT_NAME%.py
        echo         Expected: !SOURCE_PY!
        pause
        exit /b 1
    )
    copy /Y "!SOURCE_PY!" "%INSTALL_DIR%\%SCRIPT_NAME%.py" >nul
    if errorlevel 1 (
        echo [ERROR] Failed to copy %SCRIPT_NAME%.py to %INSTALL_DIR%
        pause
        exit /b 1
    )
    echo Copied %SCRIPT_NAME%.py
)

echo Updating pip...
python -m pip install --upgrade pip --quiet

echo Installing dependencies (numpy, scipy, opencv-python-headless, pyinstaller)...
python -m pip install numpy scipy opencv-python-headless pyinstaller --quiet
if errorlevel 1 (
    echo [ERROR] pip install failed. Check your internet connection and Python installation.
    pause
    exit /b 1
)

echo.
echo Building standalone executable (this may take a few minutes)...
python -m PyInstaller ^
    --onefile ^
    --name "%EXE_NAME%" ^
    --distpath "%INSTALL_DIR%" ^
    --workpath "%INSTALL_DIR%\build_tmp" ^
    --specpath "%INSTALL_DIR%\build_tmp" ^
    --noconfirm ^
    "%INSTALL_DIR%\%SCRIPT_NAME%.py"
if errorlevel 1 (
    echo [ERROR] PyInstaller build failed. See output above.
    pause
    exit /b 1
)

if exist "%INSTALL_DIR%\build_tmp" rmdir /S /Q "%INSTALL_DIR%\build_tmp"

echo.
echo ============================================================
echo  Installation complete.
echo  Executable: %INSTALL_DIR%\%EXE_NAME%.exe
echo.
echo  Usage:
echo    %EXE_NAME%.exe detect|export <same arguments as before>
echo ============================================================
echo.
pause
endlocal
