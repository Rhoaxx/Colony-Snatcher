@echo off
:: ============================================================================
:: build.bat  —  Build colony_picker_momentum.exe
:: ============================================================================
:: Run this once on the Momentum PC to produce the .exe.
:: Requirements: Python 3.8+ installed and on PATH.
::
:: Usage: double-click build.bat, or run from Command Prompt.
:: Output: C:\colony_picker\colony_picker_momentum.exe
:: ============================================================================

echo.
echo ============================================================
echo  PIXL Colony Picker — EXE Build Script
echo ============================================================
echo.

:: Check Python is available
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found on PATH.
    echo Please install Python 3.8+ from https://python.org
    echo Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)

echo [1/4] Python found:
python --version
echo.

:: Install dependencies
echo [2/4] Installing dependencies (Pillow, numpy, pyinstaller)...
pip install Pillow numpy pyinstaller --quiet
if errorlevel 1 (
    echo ERROR: pip install failed. Check your internet connection.
    pause
    exit /b 1
)
echo       Done.
echo.

:: Create output folder
echo [3/4] Creating C:\colony_picker\ ...
if not exist "C:\colony_picker" mkdir "C:\colony_picker"
if not exist "C:\colony_picker\output" mkdir "C:\colony_picker\output"
echo       Done.
echo.

:: Build the exe — call via "python -m PyInstaller" so PATH doesn't matter
echo [4/4] Building exe with PyInstaller (this takes 1-2 minutes)...
python -m PyInstaller ^
    --onefile ^
    --name colony_picker_momentum ^
    --distpath "C:\colony_picker" ^
    --workpath "%TEMP%\colony_picker_build" ^
    --specpath "%TEMP%\colony_picker_build" ^
    --hidden-import PIL ^
    --hidden-import PIL.Image ^
    --hidden-import numpy ^
    --log-level WARN ^
    colony_picker_momentum.py

if errorlevel 1 (
    echo.
    echo ERROR: PyInstaller build failed. See output above.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo  BUILD SUCCESSFUL
echo ============================================================
echo.
echo  EXE location:  C:\colony_picker\colony_picker_momentum.exe
echo  Output folder: C:\colony_picker\output\
echo.
echo  Test it by running:
echo    C:\colony_picker\colony_picker_momentum.exe
echo  (Should exit with code 99 and write an error to message.txt)
echo.
pause
