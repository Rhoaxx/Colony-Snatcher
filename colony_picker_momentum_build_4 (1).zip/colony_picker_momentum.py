#!/usr/bin/env python3
"""
colony_picker_momentum.py  —  PIXL Colony Picker, Momentum Integration
=======================================================================
Designed for two-stage execution by Thermo Fisher Momentum 7.3 via
ApplicationLauncher [Launch Application].

Arguments are received as a single comma-delimited string built by
Momentum's DataBuilder [Build Delimited Data] step.

─────────────────────────────────────────────────────────────────────
STAGE 1  —  detect
─────────────────────────────────────────────────────────────────────
Momentum passes: detect,<tracking_path>,<plate_name>,<source_type>,
                 <target_name>,<target_format>,<colony_count>,<mode>

  tracking_path   Value of PIXL_Output_Path variable from Momentum.
                  e.g. X:\\Users\\Admin\\AppData\\Roaming\\Singer Instrument
                       Company Limited\\PIXL\\Tracking\\2026_03_11\\Colony Detection
  plate_name      Source plate name  (e.g. Run1)
  source_type     SBS  |  Petri
  target_name     Target plate name  (e.g. TargetPlate1)
  target_format   DWP_96  |  SBS_96  |  DWP_384
  colony_count    Integer, number of colonies required
  mode            strict  |  relaxed

Writes:
  C:\\colony_picker\\output\\result.json   — full detection state for Stage 2
  C:\\colony_picker\\output\\message.txt   — human-readable string for operator prompt

Exit codes:
  0   Colony target met or exceeded  →  proceed automatically
  1   Below target but >0 found      →  show operator prompt (proceed / retry relaxed)
  2   Zero colonies detected         →  abort
  99  Script error                   →  abort

─────────────────────────────────────────────────────────────────────
STAGE 2  —  export
─────────────────────────────────────────────────────────────────────
Momentum passes: export,<target_name>,<colony_count>

Reads result.json written by Stage 1 (no image reprocessing).
Writes rearray CSV(s) to  \\\\LOR51185_MMTM\\C$\\
for the PIXL Rearray step to consume.

Exit codes:
  0   CSV(s) written successfully
  99  Script error  (result.json missing, output path unreachable, etc.)

─────────────────────────────────────────────────────────────────────
MOMENTUM PROCESS DESIGN
─────────────────────────────────────────────────────────────────────
Variables needed:
  String  PIXL_Output_Path   — populated by Colony Detection TrackingFilePath
  String  Plate_Name         — source plate name / barcode
  String  Source_Type        — "SBS" or "Petri"
  String  Target_Name        — target plate name
  String  Target_Format      — "DWP_96" | "SBS_96" | "DWP_384"
  String  Colony_Count       — integer as string e.g. "88"
  String  Mode               — "strict" or "relaxed"
  String  Data_Builder       — assembled by DataBuilder step
  String  Prompt_Message     — read back from message.txt for operator dialog
  Integer Exit_Code          — captured from ApplicationLauncher

Stage 1 DataBuilder fields (in order):
  "detect", PIXL_Output_Path, Plate_Name, Source_Type,
  Target_Name, Target_Format, Colony_Count, Mode

Stage 2 DataBuilder fields (in order):
  "export", Target_Name, Colony_Count

Branch routing on Exit_Code after Stage 1:
  0  →  Stage 2  →  PIXL Rearray
  1  →  Read message.txt into Prompt_Message  →  Operator dialog
         YES  →  Stage 2  →  PIXL Rearray
         NO   →  Release plate, end process
  2  →  Read message.txt into Prompt_Message  →  Operator alert, end process
  99 →  Read message.txt into Prompt_Message  →  Operator alert, end process
"""

import csv
import json
import math
import os
import sys
import time
from pathlib import Path

try:
    import numpy as np
    from PIL import Image, ImageDraw
except ImportError:
    _msg = "ERROR: Required packages missing. Run: pip install Pillow numpy"
    # Write to message.txt so Momentum can display it
    try:
        Path(r"C:\colony_picker\output").mkdir(parents=True, exist_ok=True)
        Path(r"C:\colony_picker\last_run.txt").write_text(
            str(Path(r"C:\colony_picker\output")))
        Path(r"C:\colony_picker\output\message.txt").write_text(_msg)
    except Exception:
        pass
    print(_msg, file=sys.stderr)
    sys.exit(99)


# ─────────────────────────────────────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────────────────────────────────────

# Root output directory on the Momentum PC
OUTPUT_ROOT   = Path(r"C:\colony_picker\output")

# Fixed file that always contains the path of the most recent run folder.
# Momentum reads this after Stage 1 to pass the path into Stage 2.
LAST_RUN_FILE = Path(r"C:\colony_picker\last_run.txt")

# PIXL Rearray step reads picklists from this network share
PIXL_SHARE  = Path(r"X:\Users\Admin\PIXL_Rearray")

# Fixed subfolder name matching WorkflowID = 'ColonyDetection' in PIXL process
WORKFLOW_SUBFOLDER = "ColonyDetection"

# Singer PIXL instrument constant — LED outer-to-outer physical span (mm)
# Validated against image segmentation centroids: mean error < 0.07 mm
PIXL_LED_SPAN_MM = 137.614

# Petri dish working area — 138mm internal diameter (Falcon [35]1058 150mm)
PETRI_RADIUS_MM  = 69.0

# SBS Plus plate working area (mm from centre)
SBS_X_MAX = 63.88
SBS_Y_MAX = 42.74

# Safe zone margin for relaxed subdivision (mm inside plate boundary)
EDGE_MARGIN_MM = 8.0

# Colony quality scoring weights (must match HTML tool)
W_CIRC      = 0.35
W_SIZE      = 0.15
W_ISOL      = 0.50
IDEAL_R_MM  = 0.8
HARD_CIRC   = 0.65
MERGE_R_MM  = 1.5


# ─────────────────────────────────────────────────────────────────────────────
# UTILITIES
# ─────────────────────────────────────────────────────────────────────────────

def make_run_dir(plate_name: str) -> Path:
    """
    Create and return a uniquely named run folder:
      C:/colony_picker/output/<plate_name>_YYYYMMDD_HHMMSS/
    Also writes its path to last_run.txt so Momentum can read it back
    and pass it to Stage 2.
    """
    ts      = time.strftime('%Y%m%d_%H%M%S')
    run_dir = OUTPUT_ROOT / f"{plate_name}_{ts}"
    run_dir.mkdir(parents=True, exist_ok=True)
    LAST_RUN_FILE.parent.mkdir(parents=True, exist_ok=True)
    LAST_RUN_FILE.write_text(str(run_dir))
    return run_dir


def write_message(text: str, run_dir: Path = None):
    """Write operator-facing message to message.txt for Momentum to read back."""
    target = run_dir if run_dir else OUTPUT_ROOT
    target.mkdir(parents=True, exist_ok=True)
    (target / "message.txt").write_text(text)


def abort(msg: str, code: int = 99, run_dir: Path = None):
    """Write error message and exit with given code."""
    write_message(f"ERROR: {msg}", run_dir)
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(code)


def parse_args(argv):
    """
    Parse arguments from Momentum ApplicationLauncher.

    Momentum splits the DataBuilder string on commas, passing each field as a
    separate argv item. Spaces in unquoted fields (e.g. the PIXL tracking path
    containing "Singer Instrument Company Limited") cause the OS to further
    fragment those items on whitespace.

    For 'detect': we reconstruct the tracking path by collecting argv fragments
    until we find the one ending with 'ColonyDetection', then treat the rest as
    the remaining named fields.

    For 'export': the run folder path (C:\colony_picker\output\...) contains no
    spaces, so a plain comma-rejoin + CSV parse is sufficient.
    """
    if len(argv) < 2:
        abort("No arguments received. Expected comma-delimited string from DataBuilder.")

    import csv, io

    # Strip quotes from every raw token first
    tokens = [a.strip().strip('"') for a in argv[1:]]

    if not tokens:
        abort("Argument string is empty.")

    # If Momentum passed the entire DataBuilder string as one argv item
    # (rather than splitting on commas), the first token will contain commas.
    # Split it out so the rest of the parser sees individual tokens.
    if len(tokens) == 1 and ',' in tokens[0]:
        tokens = [t.strip().strip('"') for t in tokens[0].split(',')]

    stage = tokens[0].lower()

    if stage == 'detect':
        # Reconstruct the tracking path: collect tokens from index 1 onward
        # until one ends with 'ColonyDetection' (the WorkflowID subfolder).
        path_parts = []
        tail_start = len(tokens)  # fallback: no tail
        for i in range(1, len(tokens)):
            path_parts.append(tokens[i])
            if tokens[i].lower().rstrip('\\').endswith('colonydetection'):
                tail_start = i + 1
                break

        if not path_parts:
            abort(f"Could not find tracking path in arguments: {tokens!r}")

        tracking_path = ' '.join(path_parts)

        # Momentum stores the path using the PIXL PC's local drive letter (C:).
        # Remap to the network-accessible drive letter (X:) used by this script.
        if tracking_path[:2].upper() == 'C:':
            tracking_path = 'X:' + tracking_path[2:]

        tail = tokens[tail_start:]

        if len(tail) < 6:
            abort(
                f"Stage 'detect' needs 6 fields after path "
                f"(plate_name, source_type, target_name, target_format, "
                f"colony_count, mode), got {len(tail)}.\n"
                f"  path={tracking_path!r}\n"
                f"  tail={tail!r}"
            )

        try:
            colony_count = int(tail[4])
        except ValueError:
            abort(f"colony_count must be an integer, got {tail[4]!r}")

        return {
            'stage':         'detect',
            'tracking_path': tracking_path,
            'plate_name':    tail[0],
            'source_type':   tail[1].upper(),
            'target_name':   tail[2],
            'target_format': tail[3],
            'colony_count':  colony_count,
            'mode':          tail[5].lower(),
        }

    elif stage == 'export':
        # No spaces expected — plain rejoin is fine
        raw = ','.join(tokens)
        try:
            parts = next(csv.reader(io.StringIO(raw),
                                    skipinitialspace=True, quotechar='"'))
            parts = [p.strip() for p in parts]
        except Exception:
            parts = tokens

        if len(parts) < 4:
            abort(f"Stage 'export' requires 4 fields, got {len(parts)}: {raw}")

        try:
            colony_count = int(parts[2])
        except ValueError:
            abort(f"colony_count must be an integer, got {parts[2]!r}")

        return {
            'stage':           'export',
            'target_name':     parts[1],
            'colony_count':    colony_count,
            'run_folder_path': parts[3],
        }

    else:
        abort(f"Unknown stage '{stage}'. Expected 'detect' or 'export'.")


# ─────────────────────────────────────────────────────────────────────────────
# IMAGE PATH RESOLUTION
# ─────────────────────────────────────────────────────────────────────────────

def find_image(tracking_path: str) -> Path:
    """
    Resolve Original.png from the PIXL_Output_Path variable.

    Momentum 7.3 populates PIXL_Output_Path with the full path already
    including the WorkflowID subfolder, e.g.:
      ...\\Colony Detection\\ColonyDetection

    So Original.png sits directly inside the provided path.
    We try that first, then fall back to appending the subfolder ourselves
    (in case behaviour differs across PIXL firmware versions), then do a
    recursive search as a last resort.
    """
    base = Path(tracking_path)

    if not base.exists():
        abort(f"Tracking path not found: {base}")

    # Primary: path already includes the WorkflowID subfolder
    image_path = base / "Original.png"
    if image_path.is_file():
        return image_path

    # Secondary: script appends the subfolder (older PIXL firmware)
    image_path = base / WORKFLOW_SUBFOLDER / "Original.png"
    if image_path.is_file():
        return image_path

    # Fallback: walk the tree for any Original*.png, take most recent
    candidates = list(base.rglob("Original*.png"))
    if not candidates:
        candidates = list(base.rglob("*.png"))
    if not candidates:
        abort(f"No image found under: {base}")
    return max(candidates, key=lambda p: p.stat().st_mtime)


# ─────────────────────────────────────────────────────────────────────────────
# PLATE CALIBRATION
# ─────────────────────────────────────────────────────────────────────────────

def detect_plate_calibration(gray: "np.ndarray", source_type: str):
    """
    Detect plate bounds and calibrate to PIXL coordinate system.
    Returns (plate_cx, plate_cy, px_per_mm, bounds, col_bands, row_bands).

    For SBS plates: uses LED bar outer edges + PIXL_LED_SPAN_MM constant.
    For Petri dishes: detects circular boundary from image.
    """
    H, W = gray.shape
    LED_THRESH  = 120
    GAP         = 5
    MARGIN_ROW  = 80
    MARGIN_COL  = 110

    row_means = gray.mean(axis=1)
    col_means = gray.mean(axis=0)

    def find_bands(means, length):
        bright = [i for i, m in enumerate(means) if m > LED_THRESH]
        if not bright:
            return []
        bands, s, p = [], bright[0], bright[0]
        for k in range(1, len(bright)):
            if bright[k] > p + GAP:
                bands.append((s, p))
                s = bright[k]
            p = bright[k]
        bands.append((s, p))
        return bands

    row_bands = find_bands(row_means, H)
    col_bands = find_bands(col_means, W)

    # ── Plate crop bounds ────────────────────────────────────────────────────
    if len(row_bands) >= 2:
        r1 = row_bands[0][1]  + MARGIN_ROW
        r2 = row_bands[-1][0] - MARGIN_ROW
    elif len(row_bands) == 1:
        mid = (row_bands[0][0] + row_bands[0][1]) // 2
        r1, r2 = (row_bands[0][1]+MARGIN_ROW, H-MARGIN_ROW) \
                 if mid < H//2 else (MARGIN_ROW, row_bands[0][0]-MARGIN_ROW)
    else:
        r1, r2 = int(H * 0.1), int(H * 0.9)

    if len(col_bands) >= 2:
        c1 = col_bands[0][1]  + MARGIN_COL
        c2 = col_bands[-1][0] - MARGIN_COL
    elif len(col_bands) == 1:
        mid = (col_bands[0][0] + col_bands[0][1]) // 2
        c1, c2 = (col_bands[0][1]+MARGIN_COL, W-MARGIN_COL) \
                 if mid < W//2 else (MARGIN_COL, col_bands[0][0]-MARGIN_COL)
    else:
        c1, c2 = int(W * 0.1), int(W * 0.9)

    bounds = dict(r1=r1, r2=r2, c1=c1, c2=c2)

    # ── Centre and scale ─────────────────────────────────────────────────────
    if source_type == 'PETRI':
        # For Petri dishes there are no LED bars to calibrate against.
        # Use the plate crop boundary and the known 138mm internal diameter.
        plate_cx  = (c1 + c2) / 2.0
        plate_cy  = (r1 + r2) / 2.0
        # Use the smaller of the two crop dimensions as the diameter reference
        crop_diam_px = min(c2 - c1, r2 - r1)
        px_per_mm = crop_diam_px / (PETRI_RADIUS_MM * 2.0)
    else:
        # SBS Plus plate — use LED bar OUTER edges for PIXL-calibrated scale
        if len(col_bands) >= 2:
            outer_l   = col_bands[0][0]
            outer_r   = col_bands[-1][1]
            plate_cx  = (outer_l + outer_r) / 2.0
            px_per_mm = (outer_r - outer_l) / PIXL_LED_SPAN_MM
        else:
            plate_cx  = (c1 + c2) / 2.0
            px_per_mm = (c2 - c1) / 127.76

        if len(row_bands) >= 2:
            plate_cy = (row_bands[0][0] + row_bands[-1][1]) / 2.0
        else:
            plate_cy = (r1 + r2) / 2.0

    return plate_cx, plate_cy, px_per_mm, bounds


# ─────────────────────────────────────────────────────────────────────────────
# COLONY DETECTION
# ─────────────────────────────────────────────────────────────────────────────

def otsu_threshold(values: "np.ndarray") -> int:
    hist  = np.bincount(np.clip(values.astype(np.uint8).ravel(), 0, 255),
                        minlength=256)
    total = values.size
    sum_t = float(np.dot(np.arange(256), hist))
    w_b = sum_b = best_var = 0
    otsu_t = 100
    for t in range(256):
        w_b += hist[t]
        if w_b == 0:
            continue
        w_f = total - w_b
        if w_f == 0:
            break
        sum_b += t * hist[t]
        m_b    = sum_b / w_b
        m_f    = (sum_t - sum_b) / w_f
        var    = w_b * w_f * (m_b - m_f) ** 2
        if var > best_var:
            best_var, otsu_t = var, t
    return otsu_t


def connected_components(mask: "np.ndarray") -> "np.ndarray":
    H, W    = mask.shape
    labels  = np.zeros((H, W), dtype=np.int32)
    n       = H * W + 1
    parent  = list(range(n))
    rank_   = [0] * n
    nxt     = [1]

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        pa, pb = find(a), find(b)
        if pa == pb:
            return
        if rank_[pa] < rank_[pb]:
            parent[pa] = pb
        elif rank_[pa] > rank_[pb]:
            parent[pb] = pa
        else:
            parent[pb] = pa
            rank_[pa] += 1

    for y in range(H):
        for x in range(W):
            if not mask[y, x]:
                continue
            above = int(labels[y-1, x]) if y > 0 else 0
            left  = int(labels[y, x-1]) if x > 0 else 0
            if not above and not left:
                lbl = nxt[0]; nxt[0] += 1
                parent[lbl] = lbl
                labels[y, x] = lbl
            elif above and not left:
                labels[y, x] = find(above)
            elif not above and left:
                labels[y, x] = find(left)
            else:
                labels[y, x] = find(above)
                union(above, left)

    for y in range(H):
        for x in range(W):
            if labels[y, x]:
                labels[y, x] = find(int(labels[y, x]))
    return labels


def in_plate(x_mm, y_mm, source_type):
    """Return True if the coordinate falls within the plate working area."""
    if source_type == 'PETRI':
        return math.hypot(x_mm, y_mm) <= PETRI_RADIUS_MM
    else:
        return abs(x_mm) <= SBS_X_MAX and abs(y_mm) <= SBS_Y_MAX


def detect_colonies(img_array, plate_cx, plate_cy, px_per_mm, bounds,
                    source_type='SBS', sensitivity=5,
                    min_diam_px=8, max_diam_px=50):
    """
    Detect and score colony blobs. Returns (all_blobs, oversized_blobs).
    Matches colony_picker_v4 detection algorithm exactly.
    """
    r1, r2, c1, c2 = bounds['r1'], bounds['r2'], bounds['c1'], bounds['c2']

    crop_rgb = img_array[r1:r2, c1:c2]
    gray  = (crop_rgb[:,:,0]*0.299 +
             crop_rgb[:,:,1]*0.587 +
             crop_rgb[:,:,2]*0.114).astype(np.float32)
    red   = crop_rgb[:,:,0].astype(np.float32)

    # Otsu threshold with sensitivity adjustment
    otsu_t    = otsu_threshold(gray)
    threshold = max(20, min(200, otsu_t - (sensitivity - 5) * 4))

    bg = float(gray.mean())
    if bg < 100:
        fg = gray > threshold
    else:
        redness = red / (gray * (0.587 / 0.299) + 1)
        fg = (redness > 1.05) & (gray > 80) & (gray < 220)

    labels = connected_components(fg)

    # Collect blob statistics
    blob_map = {}
    ys, xs = np.where(labels > 0)
    for y, x in zip(ys.tolist(), xs.tolist()):
        lbl = int(labels[y, x])
        if lbl not in blob_map:
            blob_map[lbl] = dict(n=0, sx=0, sy=0,
                                 x1=x, x2=x, y1=y, y2=y)
        b = blob_map[lbl]
        b['n'] += 1; b['sx'] += x; b['sy'] += y
        if x < b['x1']: b['x1'] = x
        if x > b['x2']: b['x2'] = x
        if y < b['y1']: b['y1'] = y
        if y > b['y2']: b['y2'] = y

    min_r = min_diam_px / 2.0
    max_r = max_diam_px / 2.0

    raw      = []   # blobs within size filter
    oversized = []  # blobs too large — used by relaxed mode

    for b in blob_map.values():
        rx = (b['x2'] - b['x1']) / 2.0
        ry = (b['y2'] - b['y1']) / 2.0
        r  = (rx + ry) / 2.0

        area  = b['n']
        perim = 2 * math.pi * r
        circ  = min((4 * math.pi * area) / (perim**2 + 1e-9), 1.0)
        cx    = b['sx'] / b['n'] + c1
        cy    = b['sy'] / b['n'] + r1
        x_mm  = (cx - plate_cx) / px_per_mm
        y_mm  = (cy - plate_cy) / px_per_mm

        if not in_plate(x_mm, y_mm, source_type):
            continue

        blob = dict(x=cx, y=cy, r=r,
                    x_mm=x_mm, y_mm=y_mm,
                    circularity=circ, area=area,
                    # bounding box in full-image coords for subdivision
                    x1=b['x1']+c1, x2=b['x2']+c1,
                    y1=b['y1']+r1, y2=b['y2']+r1)

        if r > max_r:
            # Too large — store for possible relaxed subdivision
            # Reject blobs near the plate boundary (wall artefacts)
            safe_x = (SBS_X_MAX - EDGE_MARGIN_MM) if source_type == 'SBS' else (PETRI_RADIUS_MM - EDGE_MARGIN_MM)
            safe_y = (SBS_Y_MAX - EDGE_MARGIN_MM) if source_type == 'SBS' else (PETRI_RADIUS_MM - EDGE_MARGIN_MM)
            if source_type == 'PETRI':
                if math.hypot(x_mm, y_mm) > safe_x:
                    continue
            else:
                if abs(x_mm) > safe_x or abs(y_mm) > safe_y:
                    continue
            # Reject extreme aspect ratio (wall reflections are tall/thin)
            bw = b['x2'] - b['x1']
            bh = b['y2'] - b['y1']
            if bw > 0 and bh > 0 and max(bw/bh, bh/bw) > 3.5:
                continue
            oversized.append(blob)
            continue

        if r < min_r:
            continue

        raw.append(blob)

    # Nearest-neighbour edge distance
    pos  = [(b['x'], b['y']) for b in raw]
    rads = [b['r'] for b in raw]
    for i, b in enumerate(raw):
        min_edge = math.inf
        for j in range(len(raw)):
            if i == j: continue
            d    = math.hypot(pos[i][0]-pos[j][0], pos[i][1]-pos[j][1])
            edge = d - rads[i] - rads[j]
            if edge < min_edge:
                min_edge = edge
        b['nn_mm'] = max(0.0, min_edge) / px_per_mm

    # Quality score
    for b in raw:
        if b['circularity'] < HARD_CIRC:
            b['quality'] = 0.0
            continue
        r_mm = b['r'] / px_per_mm
        if r_mm <= MERGE_R_MM:
            size_s = max(0.0, 1.0 - abs(r_mm - IDEAL_R_MM) / 1.5)
        else:
            size_s = max(0.0, 1.0 - (r_mm - MERGE_R_MM) * 1.5)
        circ_s = b['circularity'] ** 2
        b['quality'] = circ_s*W_CIRC + size_s*W_SIZE + min(b['nn_mm']/2, 1.0)*W_ISOL

    raw.sort(key=lambda b: b['quality'], reverse=True)
    return raw, oversized


# ─────────────────────────────────────────────────────────────────────────────
# RELAXED SELECTION
# ─────────────────────────────────────────────────────────────────────────────

def subdivide_blob(blob, typ_r, plate_cx, plate_cy, px_per_mm, source_type):
    """
    Subdivide an oversized blob into estimated single-colony centroids.
    The bounding box is clipped to the safe picking zone before gridding
    so no sub-centroid can land in the outer wall/edge strip.
    """
    cell = max(1, round(typ_r * 2.2))

    if source_type == 'SBS':
        safe_x_mm = SBS_X_MAX - EDGE_MARGIN_MM
        safe_y_mm = SBS_Y_MAX - EDGE_MARGIN_MM
    else:
        safe_x_mm = PETRI_RADIUS_MM - EDGE_MARGIN_MM
        safe_y_mm = PETRI_RADIUS_MM - EDGE_MARGIN_MM

    safe_x1 = plate_cx - safe_x_mm * px_per_mm
    safe_x2 = plate_cx + safe_x_mm * px_per_mm
    safe_y1 = plate_cy - safe_y_mm * px_per_mm
    safe_y2 = plate_cy + safe_y_mm * px_per_mm

    bx1 = max(round(blob['x1']), safe_x1)
    bx2 = min(round(blob['x2']), safe_x2)
    by1 = max(round(blob['y1']), safe_y1)
    by2 = min(round(blob['y2']), safe_y2)

    if bx2 <= bx1 or by2 <= by1:
        return []

    cols = max(1, round((bx2 - bx1) / cell))
    rows = max(1, round((by2 - by1) / cell))
    candidates = []
    for gy in range(rows):
        for gx in range(cols):
            cx    = bx1 + (gx + 0.5) * ((bx2 - bx1) / cols)
            cy    = by1 + (gy + 0.5) * ((by2 - by1) / rows)
            x_mm  = (cx - plate_cx) / px_per_mm
            y_mm  = (cy - plate_cy) / px_per_mm
            if not in_plate(x_mm, y_mm, source_type):
                continue
            candidates.append(dict(
                x=cx, y=cy, r=typ_r,
                x_mm=x_mm, y_mm=y_mm,
                circularity=0.72, area=math.pi*typ_r**2,
                nn_mm=0.0, quality=0.0,
                _relaxed=True,
            ))
    return candidates


def relaxed_select(all_blobs, oversized, needed, px_per_mm,
                   plate_cx, plate_cy, source_type):
    """
    Progressively widen the net to reach the target count.
    Phase 1: include all detected blobs regardless of circularity.
    Phase 2: subdivide oversized merged blobs in colony-dense regions.
    Returns list of up to `needed` blobs.
    """
    # Phase 1 — all detected blobs, any circularity
    pool = list(all_blobs)   # already sorted by quality desc
    if len(pool) >= needed:
        return pool[:needed]

    # Phase 2 — subdivide oversized blobs
    CELL = 80  # px grid cell size for density map

    density = {}
    for b in pool:
        gx = int(b['x'] / CELL)
        gy = int(b['y'] / CELL)
        for dx in range(-2, 3):
            for dy in range(-2, 3):
                k = (gx+dx, gy+dy)
                density[k] = density.get(k, 0) + 1

    # Median radius of quality>0 blobs for subdivision cell sizing
    qual_blobs = [b for b in all_blobs if b['quality'] > 0]
    radii = sorted(b['r'] for b in qual_blobs)
    typ_r = radii[len(radii)//2] if radii else 10.0

    extras = []
    MIN_DENSITY  = 2
    MIN_NEARBY   = 2

    for blob in oversized:
        gx = int(blob['x'] / CELL)
        gy = int(blob['y'] / CELL)
        if density.get((gx, gy), 0) < MIN_DENSITY:
            continue
        # Require >=2 clean pool colonies within 3× the blob radius
        nearby = sum(1 for p in pool
                     if math.hypot(p['x']-blob['x'], p['y']-blob['y']) < blob['r']*3)
        if nearby < MIN_NEARBY:
            continue

        subs = subdivide_blob(blob, typ_r, plate_cx, plate_cy,
                              px_per_mm, source_type)
        for s in subs:
            min_edge = math.inf
            for p in pool:
                d = math.hypot(s['x']-p['x'], s['y']-p['y']) - s['r'] - p['r']
                if d < min_edge:
                    min_edge = d
            s['nn_mm']  = max(0.0, min_edge) / px_per_mm
            s['quality'] = 0.10 + min(s['nn_mm'] / 4.0, 0.45)
        extras.extend(subs)

    # Deduplicate sub-candidates (min 0.4mm separation)
    MIN_SEP = 0.4
    extras = [s for s in extras
              if all(math.hypot(s['x']-p['x'], s['y']-p['y'])/px_per_mm > MIN_SEP
                     for p in pool)]
    extras.sort(key=lambda s: s['quality'], reverse=True)
    kept = []
    for s in extras:
        if not any(math.hypot(s['x']-k['x'], s['y']-k['y'])/px_per_mm < MIN_SEP
                   for k in kept):
            kept.append(s)

    combined = pool + kept
    return combined[:needed]


# ─────────────────────────────────────────────────────────────────────────────
# WELL ASSIGNMENT
# ─────────────────────────────────────────────────────────────────────────────

def available_wells(target_format: str) -> list:
    rows = 16 if '384' in target_format else 8
    cols = 24 if '384' in target_format else 12
    return [chr(65+r) + str(c)
            for r in range(rows)
            for c in range(1, cols+1)]


def assign_wells(colonies: list, target_format: str,
                 colony_count: int, start_well: str = 'A1') -> list:
    """
    Assign wells across one or more target plates.
    Returns list of dicts with added 'well' and 'plate_index' keys.
    """
    wells    = available_wells(target_format)
    cap      = len(wells)

    # Find start well index
    start_idx = 0
    if start_well and start_well != 'A1':
        try:
            start_idx = wells.index(start_well.upper())
        except ValueError:
            start_idx = 0

    result = []
    well_idx = start_idx
    plate    = 1

    for colony in colonies[:colony_count]:
        if well_idx >= cap:
            well_idx = 0
            plate   += 1
        entry = dict(colony)
        entry['well']        = wells[well_idx]
        entry['plate_index'] = plate
        result.append(entry)
        well_idx += 1

    return result


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 1 — DETECT
# ─────────────────────────────────────────────────────────────────────────────

def run_detect(params: dict):
    """
    Detect colonies, cache result to result.json, write message.txt.
    Returns exit code (0, 1, or 2).
    """
    # Create uniquely named run folder and register it in last_run.txt
    run_dir = make_run_dir(params['plate_name'])

    # ── Resolve image path ───────────────────────────────────────────────────
    image_path = find_image(params['tracking_path'])

    # ── Load image ───────────────────────────────────────────────────────────
    try:
        img_pil   = Image.open(image_path).convert('RGB')
        img_array = np.array(img_pil)
    except Exception as e:
        abort(f"Cannot open image '{image_path}': {e}", run_dir=run_dir)

    # ── Calibrate ────────────────────────────────────────────────────────────
    gray = (img_array[:,:,0]*0.299 +
            img_array[:,:,1]*0.587 +
            img_array[:,:,2]*0.114).astype(np.float32)

    plate_cx, plate_cy, px_per_mm, bounds = detect_plate_calibration(
        gray, params['source_type']
    )

    # ── Detect ───────────────────────────────────────────────────────────────
    all_blobs, oversized = detect_colonies(
        img_array, plate_cx, plate_cy, px_per_mm, bounds,
        source_type=params['source_type'],
    )

    # ── Select ───────────────────────────────────────────────────────────────
    target = params['colony_count']
    mode   = params['mode']

    if mode == 'relaxed':
        selected_blobs = relaxed_select(
            all_blobs, oversized, target,
            px_per_mm, plate_cx, plate_cy, params['source_type']
        )
    else:
        # Strict — only passing blobs, no expansion
        selected_blobs = [b for b in all_blobs if b['quality'] > 0][:target]

    n_found = len(selected_blobs)

    # Assign wells
    assigned = assign_wells(selected_blobs, params['target_format'],
                             target, start_well='A1')

    # ── Cache result to JSON for Stage 2 ─────────────────────────────────────
    result = {
        'timestamp':     time.strftime('%Y-%m-%dT%H:%M:%S'),
        'image_path':    str(image_path),
        'plate_name':    params['plate_name'],
        'source_type':   params['source_type'],
        'target_name':   params['target_name'],
        'target_format': params['target_format'],
        'colony_count':  target,
        'mode':          mode,
        'n_found':       n_found,
        'calibration': {
            'plate_cx':  plate_cx,
            'plate_cy':  plate_cy,
            'px_per_mm': px_per_mm,
            'bounds':    bounds,
        },
        'colonies': [
            {
                'well':        c['well'],
                'plate_index': c['plate_index'],
                'x_mm':        round((c['x'] - plate_cx) / px_per_mm, 8),
                'y_mm':        round((c['y'] - plate_cy) / px_per_mm, 8),
                'quality':     round(c['quality'], 4),
                'relaxed':     c.get('_relaxed', False),
            }
            for c in assigned
        ],
    }

    (run_dir / 'result.json').write_text(json.dumps(result, indent=2))

    # ── Determine exit code and message ──────────────────────────────────────
    if n_found == 0:
        write_message(
            f"No colonies detected on plate '{params['plate_name']}'. "
            f"Check plate image and try again.",
            run_dir
        )
        return 2

    if n_found >= target:
        write_message(
            f"{n_found} of {target} colonies found on '{params['plate_name']}'. "
            f"Ready to proceed with rearray.",
            run_dir
        )
        return 0
    else:
        write_message(
            f"Only {n_found} of {target} colonies found on "
            f"'{params['plate_name']}' ({mode} mode). "
            f"Proceed with {n_found} colonies, or abort and retry?",
            run_dir
        )
        return 1


# ─────────────────────────────────────────────────────────────────────────────
# STAGE 2 — EXPORT
# ─────────────────────────────────────────────────────────────────────────────

def run_export(params: dict):
    """
    Load cached result.json from the named run folder and write rearray
    CSV(s) to the PIXL network share and the run folder for archiving.
    Returns exit code (0 or 99).
    """
    run_dir     = Path(params['run_folder_path'])
    result_path = run_dir / 'result.json'

    if not run_dir.is_dir():
        abort(f"Run folder not found: {run_dir}")

    if not result_path.is_file():
        abort(f"result.json not found in {run_dir} — Stage 1 (detect) must run first.",
              run_dir=run_dir)

    try:
        result = json.loads(result_path.read_text())
    except Exception as e:
        abort(f"Cannot read result.json: {e}", run_dir=run_dir)

    colonies     = result['colonies']
    target_name  = result['target_name']
    target_format = result['target_format']
    plate_name   = result['plate_name']
    source_type  = result['source_type']

    if not colonies:
        abort("No colonies in result.json — nothing to export.")

    # Confirm output path is reachable
    if not PIXL_SHARE.exists():
        abort(f"PIXL network share not reachable: {PIXL_SHARE}")

    # Group colonies by plate_index
    plates: dict = {}
    for c in colonies:
        idx = c['plate_index']
        plates.setdefault(idx, []).append(c)

    src_type_str = 'Petri' if source_type == 'PETRI' else 'SBS'
    tt, tw = target_format.split('_')

    written = []
    for idx, plate_cols in sorted(plates.items()):
        fname = f"{target_name}_plate_{idx}_RearrayFile.csv"

        lines = [
            f"{plate_name},{src_type_str},None,Source,,",
            f"{target_name}_plate_{idx},{tt},{tw},Target,,",
        ]
        for c in plate_cols:
            m = __import__('re').match(r'^([A-Z])(\d+)$', c['well'])
            if not m:
                continue
            lines.append(
                f"{plate_name},"
                f"{c['y_mm']:.8f},"
                f"{c['x_mm']:.8f},"
                f"{target_name}_plate_{idx},"
                f"{m.group(1)},"
                f"{m.group(2)}"
            )
        csv_text = '\n'.join(lines) + '\n'

        # Write to PIXL network share (consumed by Rearray step)
        pixl_path = PIXL_SHARE / fname
        try:
            pixl_path.write_text(csv_text)
            written.append(str(pixl_path))
        except Exception as e:
            abort(f"Cannot write to PIXL share '{pixl_path}': {e}",
                  run_dir=run_dir)

        # Write archive copy to run folder
        (run_dir / fname).write_text(csv_text)

    write_message(
        f"Rearray file(s) written for '{plate_name}': "
        + ", ".join(written),
        run_dir
    )
    return 0


# ─────────────────────────────────────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

def main():
    params = parse_args(sys.argv)

    stage = params['stage']

    if stage == 'detect':
        code = run_detect(params)
        sys.exit(code)

    elif stage == 'export':
        code = run_export(params)
        sys.exit(code)


if __name__ == '__main__':
    main()
