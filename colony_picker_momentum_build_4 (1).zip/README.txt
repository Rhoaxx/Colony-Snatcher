PIXL Colony Picker — EXE Build Package
=======================================

Contents
--------
  colony_picker_momentum.py   The Python script (source)
  build.bat                   One-click build script for Windows


How to build the .exe
---------------------
1. Copy both files to any folder on the Momentum PC
   (e.g. C:\Users\Thermo\Desktop\colony_picker_build\)

2. Make sure Python 3.8 or newer is installed.
   Download from https://python.org if needed.
   During install, check "Add Python to PATH".

3. Double-click build.bat
   It will:
     - Install Pillow, numpy, and PyInstaller via pip
     - Compile the script into a single .exe
     - Place the .exe at C:\colony_picker\colony_picker_momentum.exe
     - Create C:\colony_picker\output\ for run data

4. The build takes 1-2 minutes. When done you will see:
     BUILD SUCCESSFUL
     EXE location: C:\colony_picker\colony_picker_momentum.exe

5. You only need to rebuild if colony_picker_momentum.py is updated.
   The source .py file is NOT needed after building — only the .exe.


Output folder structure after runs
-----------------------------------
C:\colony_picker\
  colony_picker_momentum.exe    <- the compiled tool
  last_run.txt                  <- path of most recent run (read by Momentum)
  output\
    Run1_20260311_143022\       <- unique folder per run
      result.json               <- detection cache (used by Stage 2 export)
      message.txt               <- operator message (read by Momentum)
      TargetPlate1_plate_1_RearrayFile.csv   <- archive copy of rearray file
    Run1_20260311_151205\       <- retry same plate
      ...
    Run2_20260312_090055\
      ...


Momentum ApplicationLauncher settings
--------------------------------------
  FileName:   "C:\colony_picker\colony_picker_momentum.exe"
  Arguments:  $Data_Builder   (built by DataBuilder step)
  WaitForExit: Yes
  MaxTimeout:  180  (Stage 1) / 60 (Stage 2)
  ExitCode:   Exit_Code variable


Exit codes (Stage 1)
---------------------
  0   Target met or exceeded    -> proceed to Stage 2 automatically
  1   Below target, >0 found    -> show operator prompt (proceed / abort)
  2   Zero colonies detected    -> operator alert, abort
  99  Script error              -> operator alert, abort

Exit codes (Stage 2)
---------------------
  0   CSV(s) written to \\LOR51185_MMTM\C$\  -> proceed to PIXL Rearray
  99  Error                                   -> operator alert, abort


Rebuilding after an update
---------------------------
If colony_picker_momentum.py is updated, just run build.bat again.
It will overwrite the existing .exe at C:\colony_picker\.
